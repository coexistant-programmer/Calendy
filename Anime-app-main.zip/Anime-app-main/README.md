# Anime-app

The **18+** tab is an age-confirmed, metadata-only catalog of hentai anime
powered by the unofficial [Jikan MyAnimeList API](https://docs.api.jikan.moe/).
It does not provide episodes or video streams.

AllAnime may require a CAPTCHA before playback. Complete it in the in-app
browser; Android's WebView cookie store is reused by the app across launches.
The provider controls session expiry and may require another CAPTCHA. The app
does not bypass provider access checks.