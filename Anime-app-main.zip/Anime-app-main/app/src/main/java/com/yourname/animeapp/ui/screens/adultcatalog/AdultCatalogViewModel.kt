package com.yourname.animeapp.ui.screens.adultcatalog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yourname.animeapp.core.data.settings.SettingsRepository
import com.yourname.animeapp.sources.adultcatalog.AdultAnimeMetadata
import com.yourname.animeapp.sources.adultcatalog.JikanAdultCatalog
import com.yourname.animeapp.ui.util.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@OptIn(FlowPreview::class)
@HiltViewModel
class AdultCatalogViewModel @Inject constructor(
    private val catalog: JikanAdultCatalog,
    private val settings: SettingsRepository
) : ViewModel() {

    val ageConfirmed: StateFlow<Boolean> = settings.adultCatalogConfirmed
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    val results: StateFlow<UiState<List<AdultAnimeMetadata>>> = combine(
        _query.debounce(700).distinctUntilChanged(),
        ageConfirmed
    ) { query, confirmed -> query to confirmed }
        .flatMapLatest { (query, confirmed) ->
            if (!confirmed) {
                flowOf(UiState.Success(emptyList()))
            } else {
                flow {
                    emit(UiState.Loading)
                    try {
                        emit(UiState.Success(catalog.search(query.trim())))
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (error: Exception) {
                        emit(UiState.Error(error.message ?: "Adult catalog search failed."))
                    }
                }
            }
        }
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            UiState.Success(emptyList())
        )

    fun updateQuery(query: String) {
        _query.value = query
    }

    fun confirmAge() {
        viewModelScope.launch { settings.setAdultCatalogConfirmed(true) }
    }

    fun lockCatalog() {
        viewModelScope.launch { settings.setAdultCatalogConfirmed(false) }
    }
}
