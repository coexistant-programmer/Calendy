package com.yourname.animeapp.ui.screens.downloads

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.yourname.animeapp.core.data.db.DownloadEntity
import com.yourname.animeapp.core.data.db.DownloadStatus
import com.yourname.animeapp.core.util.StorageUtil

@Composable
fun DownloadsScreen(
    viewModel: DownloadsViewModel = hiltViewModel()
) {
    val downloads by viewModel.downloads.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Downloads",
                style = MaterialTheme.typography.displayLarge
            )
        }

        if (downloads.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Nothing downloaded yet",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(downloads, key = { it.id }) { d ->
                DownloadRow(
                    download = d,
                    onPause = { viewModel.pause(d.id) },
                    onResume = { viewModel.resume(d.id) },
                    onCancel = { viewModel.cancel(d.id) }
                )
            }
        }
    }
}

@Composable
private fun DownloadRow(
    download: DownloadEntity,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = download.coverUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = download.animeTitle,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "E${formatEp(download.episodeNumber)} · ${download.translationType.uppercase()} · ${download.quality}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                when (download.status) {
                    DownloadStatus.DOWNLOADING -> {
                        val p = if (download.totalBytes > 0)
                            download.bytesDownloaded.toFloat() / download.totalBytes else 0f
                        LinearProgressIndicator(
                            progress = { p },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp)
                                .height(3.dp)
                        )
                        Text(
                            text = "${(p * 100).toInt()}% · " +
                                    "${StorageUtil.formatBytes(download.bytesDownloaded)} / " +
                                    StorageUtil.formatBytes(download.totalBytes),
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    DownloadStatus.QUEUED -> Text(
                        "Queued",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    DownloadStatus.PAUSED -> Text(
                        "Paused",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    DownloadStatus.COMPLETED -> Text(
                        if (download.localPath?.startsWith("offline-hls:") == true ||
                            download.localPath?.startsWith("offline-file:") == true
                        ) {
                            "Saved for offline playback · ${StorageUtil.formatBytes(download.totalBytes)}"
                        } else {
                            "Downloaded · ${StorageUtil.formatBytes(download.totalBytes)}"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    DownloadStatus.FAILED -> Text(
                        "Failed",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
            when (download.status) {
                DownloadStatus.DOWNLOADING, DownloadStatus.QUEUED -> IconButton(onClick = onPause) {
                    Icon(Icons.Rounded.Pause, contentDescription = "Pause")
                }
                DownloadStatus.PAUSED -> IconButton(onClick = onResume) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = "Resume")
                }
                else -> Unit
            }
            IconButton(onClick = onCancel) {
                Icon(Icons.Rounded.Close, contentDescription = "Remove")
            }
        }
    }
}

private fun formatEp(n: Double): String =
    if (n % 1.0 == 0.0) n.toInt().toString() else n.toString()
