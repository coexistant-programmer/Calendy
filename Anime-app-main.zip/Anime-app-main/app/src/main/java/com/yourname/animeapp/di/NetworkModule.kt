package com.yourname.animeapp.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.Cache
import okhttp3.OkHttpClient
import java.io.File
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides @Singleton
    fun provideOkHttp(@Named("cacheDir") cacheDir: File): OkHttpClient =
        OkHttpClient.Builder()
            .cache(Cache(File(cacheDir, "http"), 20L * 1024L * 1024L)) // hard 20 MB cap
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .addInterceptor { chain ->
                val original = chain.request()
                val builder = original.newBuilder()
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Pixel 8) " +
                            "AppleWebKit/537.36 (KHTML, like Gecko) " +
                            "Chrome/124.0.0.0 Mobile Safari/537.36")
                val host = original.url.host
                if (original.header("Referer") == null) {
                    val referer = when {
                        host == "ok.ru" || host.endsWith(".okcdn.ru") -> "https://ok.ru/"
                        host == "bysekoze.com" || host.endsWith(".bysekoze.com") ->
                            "https://bysekoze.com/"
                        else -> "https://mkissa.to/"
                    }
                    builder.header("Referer", referer)
                }
                if (original.header("Origin") == null) {
                    when {
                        host == "mkissa.to" || host.endsWith(".mkissa.to") ||
                            host == "mkissa.net" || host.endsWith(".mkissa.net") ->
                            builder.header("Origin", "https://mkissa.to")
                        host == "ok.ru" || host.endsWith(".okcdn.ru") ->
                            builder.header("Origin", "https://ok.ru")
                        host == "bysekoze.com" || host.endsWith(".bysekoze.com") ->
                            builder.header("Origin", "https://bysekoze.com")
                        else -> Unit
                    }
                }
                chain.proceed(builder.build())
            }
            .build()

    @Provides @Singleton @Named("cacheDir")
    fun provideCacheDir(@dagger.hilt.android.qualifiers.ApplicationContext ctx: android.content.Context): File =
        ctx.cacheDir
}
