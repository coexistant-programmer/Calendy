package com.yourname.animeapp.core.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WatchHistoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: WatchHistoryEntity)

    @Query("SELECT * FROM watch_history ORDER BY watchedAt DESC LIMIT :limit")
    fun observeRecent(limit: Int = 50): Flow<List<WatchHistoryEntity>>

    @Query("SELECT * FROM watch_history WHERE episodeId = :episodeId LIMIT 1")
    suspend fun get(episodeId: String): WatchHistoryEntity?

    @Query("SELECT * FROM watch_history WHERE animeId = :animeId ORDER BY watchedAt DESC LIMIT 1")
    suspend fun latestForAnime(animeId: String): WatchHistoryEntity?

    @Query("DELETE FROM watch_history WHERE episodeId = :episodeId")
    suspend fun delete(episodeId: String)

    @Query("DELETE FROM watch_history")
    suspend fun clearAll()

    @Query("DELETE FROM watch_history WHERE watchedAt < :cutoff")
    suspend fun deleteOlderThan(cutoff: Long)
}
