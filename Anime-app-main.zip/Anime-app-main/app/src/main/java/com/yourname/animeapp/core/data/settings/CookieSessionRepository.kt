package com.yourname.animeapp.core.data.settings

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CookieSession(
    val site: String,
    val capturedUrl: String,
    val capturedAt: Long,
    val cookieHeader: String
) {
    val cookieNames: List<String>
        get() = cookieHeader.split(';')
            .mapNotNull { pair -> pair.substringBefore('=').trim().takeIf(String::isNotEmpty) }
            .distinct()
}

@Singleton
class CookieSessionRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val file = File(context.noBackupFilesDir, "cookie_sessions.enc")
    private val mutex = Mutex()
    private val _sessions = MutableStateFlow<List<CookieSession>>(emptyList())
    val sessions = _sessions.asStateFlow()
    private var loaded = false

    suspend fun load() = mutex.withLock {
        loadLocked()
    }

    suspend fun save(capturedUrl: String, cookieHeader: String) = mutex.withLock {
        loadLocked()
        val uri = java.net.URI(capturedUrl)
        require(uri.scheme.equals("https", ignoreCase = true)) { "Only HTTPS sites can be saved." }
        val host = uri.host?.lowercase() ?: error("The site address has no valid host.")
        val port = if (uri.port == -1 || uri.port == 443) "" else ":${uri.port}"
        val site = "https://$host$port"
        require(cookieHeader.isNotBlank()) { "No cookies were found for this page." }

        val updated = _sessions.value
            .filterNot { it.site == site }
            .plus(CookieSession(site, capturedUrl, System.currentTimeMillis(), cookieHeader))
            .sortedBy { it.site }
        writeEncrypted(updated)
        _sessions.value = updated
    }

    suspend fun delete(site: String) = mutex.withLock {
        loadLocked()
        val updated = _sessions.value.filterNot { it.site == site }
        writeEncrypted(updated)
        _sessions.value = updated
    }

    private fun loadLocked() {
        if (loaded) return
        val sessions = if (file.exists()) {
            decode(decrypt(file.readBytes()))
        } else {
            emptyList()
        }
        _sessions.value = sessions
        loaded = true
    }

    private fun writeEncrypted(sessions: List<CookieSession>) {
        val json = JSONArray().apply {
            sessions.forEach { session ->
                put(
                    JSONObject()
                        .put("site", session.site)
                        .put("capturedUrl", session.capturedUrl)
                        .put("capturedAt", session.capturedAt)
                        .put("cookieHeader", session.cookieHeader)
                )
            }
        }.toString().toByteArray(Charsets.UTF_8)

        val encrypted = encrypt(json)
        val temporary = File(file.parentFile, "${file.name}.tmp")
        FileOutputStream(temporary).use { it.write(encrypted) }
        if (!temporary.renameTo(file)) {
            temporary.delete()
            error("Could not securely save the cookie snapshot.")
        }
    }

    private fun decode(plainText: ByteArray): List<CookieSession> {
        val json = JSONArray(String(plainText, Charsets.UTF_8))
        return (0 until json.length()).map { index ->
            val item = json.getJSONObject(index)
            CookieSession(
                site = item.getString("site"),
                capturedUrl = item.getString("capturedUrl"),
                capturedAt = item.getLong("capturedAt"),
                cookieHeader = item.getString("cookieHeader")
            )
        }
    }

    private fun encrypt(plainText: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        return cipher.iv + cipher.doFinal(plainText)
    }

    private fun decrypt(cipherText: ByteArray): ByteArray {
        require(cipherText.size > GCM_IV_LENGTH) { "The saved cookie data is invalid." }
        val iv = cipherText.copyOfRange(0, GCM_IV_LENGTH)
        val payload = cipherText.copyOfRange(GCM_IV_LENGTH, cipherText.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(GCM_TAG_LENGTH, iv))
        return cipher.doFinal(payload)
    }

    private fun secretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEY_STORE).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEY_STORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private companion object {
        const val ANDROID_KEY_STORE = "AndroidKeyStore"
        const val KEY_ALIAS = "cookie_session_vault_key"
        const val GCM_IV_LENGTH = 12
        const val GCM_TAG_LENGTH = 128
    }
}
