package com.yourname.animeapp.ui.screens.settings

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.yourname.animeapp.core.util.StorageUtil

@Composable
fun SettingsScreen(
    onAddCookieSession: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val cookieSessionViewModel: CookieSessionViewModel = hiltViewModel()
    val quality by viewModel.quality.collectAsState()
    val audio by viewModel.audio.collectAsState()
    val folderName by viewModel.folderName.collectAsState()
    val imageSize by viewModel.imageCacheSize.collectAsState()
    val downloadsSize by viewModel.downloadsCacheSize.collectAsState()
    val cookieSessions by cookieSessionViewModel.sessions.collectAsState()
    val cookieSessionError by cookieSessionViewModel.error.collectAsState()
    var sessionToDelete by remember { mutableStateOf<String?>(null) }

    sessionToDelete?.let { site ->
        AlertDialog(
            onDismissRequest = { sessionToDelete = null },
            title = { Text("Delete saved cookies?") },
            text = {
                Text("Delete the encrypted cookie snapshot for $site? This does not clear cookies held by the embedded browser.")
            },
            confirmButton = {
                TextButton(onClick = {
                    cookieSessionViewModel.delete(site)
                    sessionToDelete = null
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { sessionToDelete = null }) { Text("Cancel") }
            }
        )
    }

    val folderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            viewModel.setFolderUri(it.toString())
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Settings",
                style = MaterialTheme.typography.displayLarge
            )
        }

        item {
            SettingsCard(title = "Downloads") {
                Text(
                    text = "Download folder",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = folderName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { folderLauncher.launch(null) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Choose folder") }

                Spacer(Modifier.height(16.dp))
                Text(
                    text = "Default quality",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("AUTO", "1080", "720", "480").forEach { q ->
                        FilterChip(
                            selected = quality == q.lowercase(),
                            onClick = { viewModel.setQuality(q.lowercase()) },
                            label = { Text(q) }
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text(
                    text = "Preferred audio",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = audio == "sub",
                        onClick = { viewModel.setAudio("sub") },
                        label = { Text("Sub") }
                    )
                    FilterChip(
                        selected = audio == "dub",
                        onClick = { viewModel.setAudio("dub") },
                        label = { Text("Dub") }
                    )
                }
            }
        }

        item {
            SettingsCard(title = "Storage") {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Image cache", modifier = Modifier.weight(1f))
                    Text(StorageUtil.formatBytes(imageSize))
                }
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Download cache", modifier = Modifier.weight(1f))
                    Text(StorageUtil.formatBytes(downloadsSize))
                }
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = viewModel::clearImageCache,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Clear image cache") }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = viewModel::deleteAllDownloads,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Delete all downloads") }
            }
        }

        item {
            SettingsCard(title = "Cookie & Session Management") {
                Text(
                    text = "Save encrypted, on-device cookie snapshots for reviewing and managing your own site sessions. Values are never shown or uploaded. Snapshots are not replayed into app network requests; the embedded browser uses its own cookies. Deleting a snapshot does not clear browser cookies.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Use only accounts and sites you are authorized to access. Follow each site's terms and access policies. Embedded browsers may be blocked; complete any CAPTCHA yourself in the browser.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onAddCookieSession,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Add") }

                if (cookieSessionError != null) {
                    Text(
                        text = cookieSessionError.orEmpty(),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                cookieSessions.forEach { session ->
                    Spacer(Modifier.height(12.dp))
                    Text(session.site, style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = "Cookies: ${session.cookieNames.joinToString().ifBlank { "None" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Values hidden | Saved ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(session.capturedAt))}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = { sessionToDelete = session.site }) {
                        Text("Delete saved snapshot")
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Card(
        shape = MaterialTheme.shapes.large,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            content()
        }
    }
}
