package com.yourname.animeapp.ui.player

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.media.AudioManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.yourname.animeapp.sources.allanime.AllAnimeWebSession
import com.yourname.animeapp.ui.components.AllAnimeCaptchaDialog
import kotlinx.coroutines.delay

@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    onBack: () -> Unit,
    viewModel: PlayerViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val audioManager = remember(context) {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    var controlsVisible by remember { mutableStateOf(true) }
    var showTrackSheet by remember { mutableStateOf(false) }
    var showSpeedSheet by remember { mutableStateOf(false) }
    var showCaptcha by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var brightness by remember { mutableFloatStateOf(0.5f) }

    val view = LocalView.current
    LaunchedEffect(state.captchaUrl) {
        showCaptcha = state.captchaUrl != null
    }

    DisposableEffect(Unit) {
        val window = activity?.window
        val controller = window?.let {
            WindowCompat.getInsetsController(it, it.decorView)
        }
        controller?.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            activity?.window?.attributes?.screenBrightness =
                android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        }
    }

    LaunchedEffect(state.isPlaying, controlsVisible) {
        if (controlsVisible && state.isPlaying) {
            delay(3_500)
            controlsVisible = false
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = viewModel.player
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                }
            },
            update = { it.player = viewModel.player },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(scaleX = zoom, scaleY = zoom)
        )

        Box(
            Modifier
                .fillMaxSize()
                .playerGestures(
                    enabled = !state.isLocked,
                    onTap = { controlsVisible = !controlsVisible },
                    onDoubleTap = { forward ->
                        viewModel.seekBy(if (forward) 10_000L else -10_000L)
                    },
                    onSeek = { viewModel.seekBy(it) },
                    onBrightness = { delta ->
                        val step = if (delta > 0) 0.03f else -0.03f
                        brightness = (brightness + step).coerceIn(0.02f, 1f)
                        activity?.window?.let { w ->
                            val attrs = w.attributes
                            attrs.screenBrightness = brightness
                            w.attributes = attrs
                        }
                    },
                    onVolume = { delta ->
                        val dir = if (delta > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
                        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, 0)
                    },
                    onZoom = { factor ->
                        zoom = (zoom * factor).coerceIn(1f, 3f)
                    }
                )
        )

        AnimatedVisibility(
            visible = controlsVisible || !state.isPlaying,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            PlayerControls(
                state = state,
                onBack = onBack,
                onToggleLock = viewModel::toggleLock,
                onPlayPause = viewModel::togglePlayPause,
                onSeek = viewModel::seekTo,
                onBack10 = { viewModel.seekBy(-10_000L) },
                onForward10 = { viewModel.seekBy(10_000L) },
                onOpenTracks = { showTrackSheet = true },
                onOpenSpeed = { showSpeedSheet = true }
            )
        }

        if (state.isLoading) {
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        state.error?.let { msg ->
            Column(
                modifier = Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = msg, color = Color.Red)
                if (state.captchaUrl != null) {
                    TextButton(onClick = { showCaptcha = true }) {
                        Text("Open CAPTCHA")
                    }
                } else {
                    TextButton(onClick = viewModel::retryPlayback) {
                        Text("Retry")
                    }
                }
            }
        }
    }

    val captchaUrl = state.captchaUrl
    if (showCaptcha && captchaUrl != null) {
        AllAnimeCaptchaDialog(
            url = captchaUrl,
            onDismiss = { showCaptcha = false },
            onRetry = {
                showCaptcha = false
                AllAnimeWebSession.flushCookies()
                viewModel.retryAfterCaptcha()
            }
        )
    }

    if (showTrackSheet) {
        TrackSelectorSheet(
            audioTracks = state.audioTracks,
            textTracks = state.textTracks,
            selectedAudioId = state.selectedAudioId,
            selectedTextId = state.selectedTextId,
            onSelectAudio = {
                viewModel.selectAudio(it)
                showTrackSheet = false
            },
            onSelectText = {
                viewModel.selectText(it)
                showTrackSheet = false
            },
            onDismiss = { showTrackSheet = false }
        )
    }

    if (showSpeedSheet) {
        ModalBottomSheet(onDismissRequest = { showSpeedSheet = false }) {
            listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                ListItem(
                    headlineContent = { Text("${s}x") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                        .clickable {
                            viewModel.setSpeed(s)
                            showSpeedSheet = false
                        }
                )
            }
        }
    }
}

private fun Context.findActivity(): Activity? {
    var ctx: Context = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}
