package com.yourname.animeapp.sources.adultcatalog

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

data class AdultAnimeMetadata(
    val id: Int,
    val title: String,
    val imageUrl: String?,
    val synopsis: String?,
    val rating: String?,
    val score: Double?
)

@Singleton
class JikanAdultCatalog @Inject constructor(
    private val client: OkHttpClient
) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun search(query: String): List<AdultAnimeMetadata> = withContext(Dispatchers.IO) {
        val url = "https://api.jikan.moe/v4/anime".toHttpUrl().newBuilder()
            .addQueryParameter("genres", HENTAI_GENRE_ID)
            .addQueryParameter("limit", PAGE_SIZE)
            .addQueryParameter("order_by", if (query.isBlank()) "score" else "title")
            .addQueryParameter("sort", "desc")
            .apply {
                if (query.isNotBlank()) addQueryParameter("q", query)
            }
            .build()
        val request = Request.Builder()
            .url(url)
            .header("Referer", "https://jikan.moe/")
            .header("Origin", "https://jikan.moe")
            .get()
            .build()

        val responseBody = client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Adult catalog request failed (HTTP ${response.code}).")
            }
            response.body?.string()?.takeIf(String::isNotBlank)
                ?: throw IOException("Adult catalog returned an empty response.")
        }

        json.decodeFromString<JikanResponse>(responseBody).data.map { anime ->
            AdultAnimeMetadata(
                id = anime.id,
                title = anime.englishTitle?.takeIf(String::isNotBlank)
                    ?: anime.title?.takeIf(String::isNotBlank)
                    ?: "Untitled",
                imageUrl = anime.images?.jpg?.imageUrl,
                synopsis = anime.synopsis,
                rating = anime.rating,
                score = anime.score
            )
        }
    }

    private companion object {
        const val HENTAI_GENRE_ID = "12"
        const val PAGE_SIZE = "24"
    }
}

@Serializable
private data class JikanResponse(
    val data: List<JikanAnime> = emptyList()
)

@Serializable
private data class JikanAnime(
    @SerialName("mal_id") val id: Int,
    val title: String? = null,
    @SerialName("title_english") val englishTitle: String? = null,
    val synopsis: String? = null,
    val rating: String? = null,
    val score: Double? = null,
    val images: JikanImages? = null
)

@Serializable
private data class JikanImages(
    val jpg: JikanImage? = null
)

@Serializable
private data class JikanImage(
    @SerialName("image_url") val imageUrl: String? = null
)
