package com.yourname.animeapp.ui.components

import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.yourname.animeapp.sources.allanime.AllAnimeCaptchaStore
import com.yourname.animeapp.sources.allanime.AllAnimeWebSession
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Shared AllAnime Turnstile dialog. The WebView completes the provider challenge
 * and hands the resulting single-use token to [AllAnimeCaptchaStore]. The caller
 * retries the failed request when [onRetry] fires.
 */
@Composable
fun AllAnimeCaptchaDialog(
    url: String,
    onDismiss: () -> Unit,
    onRetry: () -> Unit,
) {
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val captured = remember { AtomicBoolean(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("AllAnime CAPTCHA") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Complete the security check below. The request retries automatically when the check succeeds. " +
                        "The app saves and reuses the provider's WebView cookies across launches; " +
                        "the provider may expire them and require another check. " +
                        "If the page says access is blocked, the provider has denied this request; " +
                        "retrying will not bypass that block."
                )
                if (AllAnimeWebSession.isTrustedWebViewUrl(url)) {
                    AndroidView(
                        factory = { context ->
                            WebView(context).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.useWideViewPort = true
                                settings.loadWithOverviewMode = true
                                AllAnimeWebSession.enableCookies()
                                android.webkit.CookieManager.getInstance()
                                    .setAcceptThirdPartyCookies(this, true)
                                webChromeClient = WebChromeClient()
                                addJavascriptInterface(object {
                                    @JavascriptInterface
                                    fun onCaptcha(token: String, provider: String) {
                                        if (token.isBlank()) return
                                        if (!captured.compareAndSet(false, true)) return
                                        AllAnimeCaptchaStore.save(token, provider)
                                        mainHandler.post { onRetry() }
                                    }
                                }, "AA")
                                webViewClient = object : WebViewClient() {
                                    override fun onPageFinished(view: WebView, url: String) {
                                        AllAnimeWebSession.flushCookies()
                                        view.evaluateJavascript(
                                            """
                                            (function() {
                                              function report(token, provider) {
                                                try { AA.onCaptcha(token, provider || 'turnstile'); } catch (e) {}
                                              }
                                              var original = window.captchaCallback;
                                              window.captchaCallback = function(token) {
                                                report(token, 'turnstile');
                                                try { if (original) original(token); } catch (e) {}
                                              };
                                              setInterval(function() {
                                                var el = document.querySelector('input[name="cf-turnstile-response"]');
                                                if (el && el.value) report(el.value, 'turnstile');
                                              }, 500);
                                            })();
                                            """.trimIndent(),
                                            null
                                        )
                                    }

                                    override fun shouldOverrideUrlLoading(
                                        view: WebView,
                                        request: WebResourceRequest,
                                    ): Boolean =
                                        !AllAnimeWebSession.isTrustedWebViewUrl(request.url.toString())
                                }
                                loadUrl(url)
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(420.dp),
                        onRelease = { webView ->
                            webView.stopLoading()
                            webView.destroy()
                        }
                    )
                } else {
                    Text("The CAPTCHA page URL is not supported.")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onRetry) {
                Text("Retry")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
