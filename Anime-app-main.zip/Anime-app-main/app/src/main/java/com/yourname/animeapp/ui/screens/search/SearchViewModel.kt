package com.yourname.animeapp.ui.screens.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yourname.animeapp.core.data.AnimeRepository
import com.yourname.animeapp.core.data.db.SearchHistoryEntity
import com.yourname.animeapp.core.data.model.AnimeSummary
import com.yourname.animeapp.ui.util.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val animeRepo: AnimeRepository,
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _results = MutableStateFlow<UiState<List<AnimeSummary>>>(UiState.Success(emptyList()))
    val results: StateFlow<UiState<List<AnimeSummary>>> = _results.asStateFlow()

    private val _hasMore = MutableStateFlow(false)
    val hasMore: StateFlow<Boolean> = _hasMore.asStateFlow()

    private val _isLoadingMore = MutableStateFlow(false)
    val isLoadingMore: StateFlow<Boolean> = _isLoadingMore.asStateFlow()

    private val _loadMoreError = MutableStateFlow<String?>(null)
    val loadMoreError: StateFlow<String?> = _loadMoreError.asStateFlow()

    private var activeQuery = ""
    private var currentPage = 1
    private var loadMoreJob: Job? = null

    init {
        viewModelScope.launch {
            _query
                .debounce(350)
                .distinctUntilChanged()
                .collectLatest { rawQuery ->
                    val searchQuery = rawQuery.trim()
                    loadMoreJob?.cancel()
                    _isLoadingMore.value = false
                    _loadMoreError.value = null
                    activeQuery = searchQuery
                    currentPage = 1
                    _hasMore.value = false

                    if (searchQuery.isBlank()) {
                        _results.value = UiState.Success(emptyList())
                        return@collectLatest
                    }

                    _results.value = UiState.Loading
                    try {
                        val page = animeRepo.search(searchQuery)
                        _results.value = UiState.Success(page.items.distinctBy { it.id })
                        _hasMore.value = page.hasNextPage
                    } catch (cancellation: CancellationException) {
                        throw cancellation
                    } catch (error: Exception) {
                        _results.value = UiState.Error(error.message ?: "Search failed")
                    }
                }
        }
    }

    fun loadNextPage() {
        val searchQuery = activeQuery
        if (
            searchQuery.isBlank() ||
            _query.value.trim() != searchQuery ||
            !_hasMore.value ||
            _isLoadingMore.value
        ) return

        val pageNumber = currentPage + 1
        _isLoadingMore.value = true
        _loadMoreError.value = null
        loadMoreJob = viewModelScope.launch {
            try {
                val page = animeRepo.search(searchQuery, pageNumber)
                if (activeQuery != searchQuery || _query.value.trim() != searchQuery) return@launch

                val currentItems = (_results.value as? UiState.Success)?.data.orEmpty()
                _results.value = UiState.Success((currentItems + page.items).distinctBy { it.id })
                currentPage = pageNumber
                _hasMore.value = page.hasNextPage
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Exception) {
                if (activeQuery == searchQuery) {
                    _loadMoreError.value = error.message ?: "Couldn't load more results"
                }
            } finally {
                if (activeQuery == searchQuery) _isLoadingMore.value = false
            }
        }
    }

    fun retrySearch() {
        val searchQuery = _query.value.trim()
        if (searchQuery.isBlank()) return

        loadMoreJob?.cancel()
        _hasMore.value = false
        _isLoadingMore.value = false
        _loadMoreError.value = null
        _results.value = UiState.Loading
        viewModelScope.launch {
            try {
                val page = animeRepo.search(searchQuery)
                if (_query.value.trim() != searchQuery) return@launch

                activeQuery = searchQuery
                currentPage = 1
                _results.value = UiState.Success(page.items.distinctBy { it.id })
                _hasMore.value = page.hasNextPage
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Exception) {
                if (_query.value.trim() == searchQuery) {
                    _results.value = UiState.Error(error.message ?: "Search failed")
                }
            }
        }
    }

    val searchHistory: StateFlow<List<SearchHistoryEntity>> =
        animeRepo.observeSearchHistory()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun updateQuery(q: String) {
        if (q.trim() != _query.value.trim()) {
            loadMoreJob?.cancel()
            _hasMore.value = false
            _isLoadingMore.value = false
            _loadMoreError.value = null
        }
        _query.value = q
    }
}
