package com.yourname.animeapp.core.data

import com.yourname.animeapp.core.data.db.SearchHistoryDao
import com.yourname.animeapp.core.data.db.SearchHistoryEntity
import com.yourname.animeapp.core.data.db.WatchHistoryDao
import com.yourname.animeapp.core.data.db.WatchHistoryEntity
import com.yourname.animeapp.core.data.model.AnimeDetails
import com.yourname.animeapp.core.data.model.AnimeSource
import com.yourname.animeapp.core.data.model.AnimeSummary
import com.yourname.animeapp.core.data.model.Episode
import com.yourname.animeapp.core.data.model.PagedResult
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AnimeRepository @Inject constructor(
    private val source: AnimeSource,
    private val historyDao: WatchHistoryDao,
    private val searchDao: SearchHistoryDao,
) {

    suspend fun search(query: String, page: Int = 1): PagedResult<AnimeSummary> {
        val result = source.search(query, page)
        if (page == 1 && query.isNotBlank() && result.items.isNotEmpty()) {
            searchDao.upsert(SearchHistoryEntity(query, System.currentTimeMillis()))
        }
        return result
    }

    suspend fun trending(page: Int = 1): PagedResult<AnimeSummary> = source.trending(page)

    suspend fun details(id: String): AnimeDetails = source.details(id)

    suspend fun episodes(animeId: String): List<Episode> = source.episodes(animeId)

    fun observeHistory(limit: Int = 50): Flow<List<WatchHistoryEntity>> =
        historyDao.observeRecent(limit)

    suspend fun latestForAnime(animeId: String): WatchHistoryEntity? =
        historyDao.latestForAnime(animeId)

    fun observeSearchHistory() = searchDao.observeRecent()

    suspend fun recordWatch(
        anime: AnimeDetails,
        episode: Episode,
        positionMs: Long,
        durationMs: Long,
    ) {
        historyDao.upsert(
            WatchHistoryEntity(
                episodeId = episode.id,
                animeId = anime.id,
                sourceId = anime.sourceId,
                animeTitle = anime.title,
                coverUrl = anime.coverUrl,
                episodeNumber = episode.number,
                translationType = episode.translationType,
                lastPositionMs = positionMs,
                durationMs = durationMs,
                completed = durationMs > 0 && positionMs >= durationMs - 5000,
                watchedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun clearHistory() = historyDao.clearAll()
}
