package com.yourname.animeapp.ui.screens.settings

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yourname.animeapp.core.data.DownloadRepository
import com.yourname.animeapp.core.data.settings.SettingsRepository
import com.yourname.animeapp.core.util.StorageUtil
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settings: SettingsRepository,
    private val downloadRepo: DownloadRepository,
) : ViewModel() {

    val quality: StateFlow<String> =
        settings.defaultQuality.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "1080")

    val audio: StateFlow<String> =
        settings.defaultAudio.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "sub")

    private val _folderName = MutableStateFlow("Not set")
    val folderName: StateFlow<String> = _folderName.asStateFlow()

    private val _imageCacheSize = MutableStateFlow(0L)
    val imageCacheSize: StateFlow<Long> = _imageCacheSize.asStateFlow()

    private val _downloadsCacheSize = MutableStateFlow(0L)
    val downloadsCacheSize: StateFlow<Long> = _downloadsCacheSize.asStateFlow()

    init {
        viewModelScope.launch {
            settings.downloadTreeUri.collect { uriStr ->
                _folderName.value = if (uriStr == null) "Not set" else resolveFolderName(uriStr)
            }
        }
        refreshSizes()
    }

    private suspend fun resolveFolderName(uriStr: String): String = withContext(Dispatchers.IO) {
        runCatching {
            DocumentFile.fromTreeUri(context, Uri.parse(uriStr))?.name
        }.getOrNull() ?: "Selected"
    }

    fun refreshSizes() {
        viewModelScope.launch {
            _imageCacheSize.value = withContext(Dispatchers.IO) {
                StorageUtil.dirSize(File(context.cacheDir, "image_cache"))
            }
            _downloadsCacheSize.value = withContext(Dispatchers.IO) {
                val dir = File(context.getExternalFilesDir(null) ?: context.filesDir, "downloads_cache")
                StorageUtil.dirSize(dir)
            }
        }
    }

    fun setQuality(v: String) { viewModelScope.launch { settings.setDefaultQuality(v) } }
    fun setAudio(v: String)   { viewModelScope.launch { settings.setDefaultAudio(v) } }
    fun setFolderUri(uri: String) { viewModelScope.launch { settings.setDownloadTreeUri(uri) } }

    fun clearImageCache() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                StorageUtil.clearContents(File(context.cacheDir, "image_cache"))
            }
            refreshSizes()
        }
    }

    fun deleteAllDownloads() {
        viewModelScope.launch {
            val all = downloadRepo.observeAll().first()
            all.forEach { downloadRepo.cancel(it.id) }
            refreshSizes()
        }
    }
}
