package com.yourname.animeapp.core.data

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.annotation.OptIn
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.C
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import com.yourname.animeapp.core.data.db.DownloadDao
import com.yourname.animeapp.core.data.db.DownloadEntity
import com.yourname.animeapp.core.data.db.DownloadStatus
import com.yourname.animeapp.core.data.model.AnimeSource
import com.yourname.animeapp.core.data.model.Episode
import com.yourname.animeapp.core.data.model.Quality
import com.yourname.animeapp.core.data.settings.SettingsRepository
import com.yourname.animeapp.core.download.AnimeDownloadService
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@OptIn(markerClass = [UnstableApi::class])
@Singleton
class DownloadRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val source: AnimeSource,
    private val downloadManager: DownloadManager,
    private val downloadDao: DownloadDao,
    private val settings: SettingsRepository,
    private val cache: SimpleCache,
    private val dataSourceFactory: DataSource.Factory,
) {

    fun observeAll(): Flow<List<DownloadEntity>> = downloadDao.observeAll()

    fun observeForAnime(animeId: String): Flow<List<DownloadEntity>> =
        downloadDao.observeForAnime(animeId)

    suspend fun enqueue(
        animeId: String,
        animeTitle: String,
        coverUrl: String?,
        episode: Episode,
        quality: Quality,
    ): Result<Unit> = try {
        val downloadId = "${episode.id}::${quality.name}"

        val existing = downloadDao.get(downloadId)
        if (existing != null && existing.status in listOf(
                DownloadStatus.QUEUED,
                DownloadStatus.DOWNLOADING,
                DownloadStatus.COMPLETED
            )
        ) {
            Result.success(Unit)
        } else {
            val free = context.getExternalFilesDir(null)?.usableSpace ?: 0L
            if (free < MIN_FREE_BYTES) {
                error("Not enough storage. Need ${MIN_FREE_BYTES / (1024 * 1024)} MB free.")
            }

            val sources = source.streamSources(episode.id, episode.translationType, quality)
            val best = sources.firstOrNull() ?: error("No playable source found for this episode")

            val requestBuilder = DownloadRequest.Builder(downloadId, Uri.parse(best.url))
                .setMimeType(if (best.isHls) MimeTypes.APPLICATION_M3U8 else MimeTypes.VIDEO_MP4)
            if (!best.isHls) requestBuilder.setCustomCacheKey(downloadId)
            val request = requestBuilder.build()

            val now = System.currentTimeMillis()
            downloadDao.upsert(
                DownloadEntity(
                    id = downloadId,
                    animeId = animeId,
                    animeTitle = animeTitle,
                    coverUrl = coverUrl,
                    episodeId = episode.id,
                    episodeNumber = episode.number,
                    translationType = episode.translationType,
                    quality = quality.name,
                    status = DownloadStatus.QUEUED,
                    bytesDownloaded = 0,
                    totalBytes = 0,
                    localPath = null,
                    exportedUri = null,
                    error = null,
                    createdAt = now,
                    updatedAt = now
                )
            )

            DownloadService.sendAddDownload(
                context,
                AnimeDownloadService::class.java,
                request,
                /* foreground = */ true
            )
            Result.success(Unit)
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }

    fun pause(id: String) {
        runCatching {
            downloadManager.setStopReason(id, STOP_REASON_PAUSED_BY_APP)
        }
    }

    fun resume(id: String) {
        runCatching {
            downloadManager.setStopReason(id, STOP_REASON_NONE)
        }
    }

    suspend fun cancel(id: String) = withContext(Dispatchers.IO) {
        DownloadService.sendRemoveDownload(context, AnimeDownloadService::class.java, id, true)
        downloadDao.delete(id)
    }

    suspend fun handleDownloadChanged(download: Download) = withContext(Dispatchers.IO) {
        val entity = downloadDao.get(download.request.id) ?: return@withContext
        val now = System.currentTimeMillis()

        when (download.state) {
            Download.STATE_DOWNLOADING -> downloadDao.updateProgress(
                entity.id, DownloadStatus.DOWNLOADING,
                download.bytesDownloaded, download.contentLength, now
            )
            Download.STATE_QUEUED -> downloadDao.updateProgress(
                entity.id, DownloadStatus.QUEUED,
                download.bytesDownloaded, download.contentLength, now
            )
            Download.STATE_STOPPED -> downloadDao.updateProgress(
                entity.id, DownloadStatus.PAUSED,
                download.bytesDownloaded, download.contentLength, now
            )
            Download.STATE_FAILED -> downloadDao.markFailed(
                entity.id, DownloadStatus.FAILED,
                download.failureReason.toString(), now
            )
            Download.STATE_COMPLETED -> {
                val isHls = download.request.mimeType == MimeTypes.APPLICATION_M3U8
                val exported = if (isHls) null else exportToUserFolder(download, entity)
                val offlineCache = when {
                    isHls -> DownloadEntity.OFFLINE_HLS_PREFIX + download.request.uri
                    exported == null -> DownloadEntity.OFFLINE_FILE_PREFIX + download.request.uri
                    else -> null
                }
                downloadDao.markCompleted(
                    entity.id,
                    DownloadStatus.COMPLETED,
                    exported,
                    offlineCache,
                    now
                )
                if (exported != null) {
                    runCatching { downloadManager.removeDownload(download.request.id) }
                }
            }
            Download.STATE_REMOVING -> Unit
            else -> Unit
        }
    }

    private suspend fun exportToUserFolder(
        download: Download,
        entity: DownloadEntity,
    ): String? = withContext(Dispatchers.IO) {
        val treeUriStr = settings.downloadTreeUri.first() ?: return@withContext null
        val treeUri = runCatching { Uri.parse(treeUriStr) }.getOrNull() ?: return@withContext null
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext null

        val animeDir = root.findFile(entity.animeTitle)
            ?: root.createDirectory(entity.animeTitle)
            ?: return@withContext null

        val fileName = buildFileName(entity)
        animeDir.findFile(fileName)?.delete()
        val target = animeDir.createFile("video/mp4", fileName) ?: return@withContext null

        val cacheKey = download.request.customCacheKey ?: download.request.uri.toString()
        val cacheSource = CacheDataSource.Factory()
            .setCache(cache)
            .setCacheKeyFactory { _ -> cacheKey }
            .setUpstreamDataSourceFactory(dataSourceFactory)
            .createDataSource()

        val dataSpec = DataSpec(download.request.uri)
        try {
            val output = context.contentResolver.openOutputStream(target.uri)
                ?: error("Unable to open the selected download folder")
            output.use { out ->
                cacheSource.open(dataSpec)
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val read = cacheSource.read(buf, 0, buf.size)
                    if (read == C.RESULT_END_OF_INPUT) break
                    out.write(buf, 0, read)
                }
            }
            target.uri.toString()
        } catch (e: CancellationException) {
            target.delete()
            throw e
        } catch (e: Exception) {
            target.delete()
            Log.e("DownloadRepository", "Could not export completed download; keeping its offline cache", e)
            null
        } finally {
            runCatching { cacheSource.close() }
        }
    }

    private fun buildFileName(entity: DownloadEntity): String {
        val ep = if (entity.episodeNumber % 1.0 == 0.0)
            entity.episodeNumber.toInt().toString().padStart(3, '0')
        else
            entity.episodeNumber.toString()
        return "E$ep - ${entity.animeTitle} [${entity.translationType}].mp4"
    }

    companion object {
        private const val MIN_FREE_BYTES = 500L * 1024L * 1024L
        private const val STOP_REASON_NONE = 0
        private const val STOP_REASON_PAUSED_BY_APP = 1
    }
}
