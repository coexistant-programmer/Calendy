package com.yourname.animeapp.core.data.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "settings")

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val KEY_TREE_URI = stringPreferencesKey("download_tree_uri")
    private val KEY_DEFAULT_QUALITY = stringPreferencesKey("default_quality")
    private val KEY_DEFAULT_AUDIO = stringPreferencesKey("default_audio")
    private val KEY_EXPORT_TO_VIDEO = booleanPreferencesKey("export_to_video")
    private val KEY_ADULT_CATALOG_CONFIRMED = booleanPreferencesKey("adult_catalog_confirmed")

    val downloadTreeUri: Flow<String?> = context.dataStore.data.map { it[KEY_TREE_URI] }
    val defaultQuality: Flow<String> = context.dataStore.data.map { it[KEY_DEFAULT_QUALITY] ?: "1080" }
    val defaultAudio: Flow<String> = context.dataStore.data.map { it[KEY_DEFAULT_AUDIO] ?: "sub" }
    val exportToVideo: Flow<Boolean> = context.dataStore.data.map { it[KEY_EXPORT_TO_VIDEO] ?: true }
    val adultCatalogConfirmed: Flow<Boolean> =
        context.dataStore.data.map { it[KEY_ADULT_CATALOG_CONFIRMED] ?: false }

    suspend fun setDownloadTreeUri(uri: String?) {
        context.dataStore.edit { prefs ->
            if (uri == null) prefs.remove(KEY_TREE_URI) else prefs[KEY_TREE_URI] = uri
        }
    }

    suspend fun setDefaultQuality(v: String) {
        context.dataStore.edit { it[KEY_DEFAULT_QUALITY] = v }
    }

    suspend fun setDefaultAudio(v: String) {
        context.dataStore.edit { it[KEY_DEFAULT_AUDIO] = v }
    }

    suspend fun setExportToVideo(v: Boolean) {
        context.dataStore.edit { it[KEY_EXPORT_TO_VIDEO] = v }
    }

    suspend fun setAdultCatalogConfirmed(confirmed: Boolean) {
        context.dataStore.edit { it[KEY_ADULT_CATALOG_CONFIRMED] = confirmed }
    }
}
