package com.yourname.animeapp.core.util

/**
 * AllAnime obfuscates some source URLs as `--<hex>` and `ap/<hex>`.
 * Any decode failure returns null — callers must skip the entry, never crash.
 */
object HexDecoder {

    fun decodeSourceUrl(raw: String): String? {
        val xorEncoded = raw.startsWith("--")
        val hexEncoded = raw.startsWith("ap/")
        if (!xorEncoded && !hexEncoded) return raw

        val encoded = raw.removePrefix("--").removePrefix("ap/")
        if (encoded.isEmpty() || encoded.length % 2 != 0) return null
        return try {
            val bytes = ByteArray(encoded.length / 2) { index ->
                encoded.substring(index * 2, index * 2 + 2).toInt(16).toByte()
            }
            if (xorEncoded) {
                bytes.indices.forEach { bytes[it] = (bytes[it].toInt() xor 0x38).toByte() }
            }
            String(bytes, Charsets.UTF_8).replace("\\/", "/")
        } catch (e: NumberFormatException) {
            null
        }
    }
}
