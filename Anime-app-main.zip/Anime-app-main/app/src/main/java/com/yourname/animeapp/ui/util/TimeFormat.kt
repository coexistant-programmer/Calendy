package com.yourname.animeapp.ui.util

fun formatDuration(ms: Long): String {
    if (ms <= 0) return "0:00"
    val totalSec = ms / 1000
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun formatEpisodeLabel(number: Double, translationType: String): String {
    val n = if (number % 1.0 == 0.0) number.toInt().toString() else number.toString()
    val tag = if (translationType == "dub") "DUB" else "SUB"
    return "E$n · $tag"
}
