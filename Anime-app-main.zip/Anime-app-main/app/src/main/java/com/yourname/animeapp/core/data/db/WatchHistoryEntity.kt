package com.yourname.animeapp.core.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "watch_history",
    indices = [
        Index("animeId"),
        Index("watchedAt")
    ]
)
data class WatchHistoryEntity(
    @PrimaryKey val episodeId: String,
    val animeId: String,
    val sourceId: String,
    val animeTitle: String,
    val coverUrl: String?,
    val episodeNumber: Double,
    val translationType: String,
    val lastPositionMs: Long,
    val durationMs: Long,
    val completed: Boolean,
    val watchedAt: Long
)
