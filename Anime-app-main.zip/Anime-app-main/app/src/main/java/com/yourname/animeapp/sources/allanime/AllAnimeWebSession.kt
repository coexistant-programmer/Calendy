package com.yourname.animeapp.sources.allanime

import android.webkit.CookieManager
import java.net.URI

object AllAnimeWebSession {
    private val allAnimeHosts = listOf("mkissa.to", "mkissa.net")
    private val challengeHosts = setOf("challenges.cloudflare.com", "challenges.cloudflare.net")

    fun enableCookies() {
        CookieManager.getInstance().setAcceptCookie(true)
    }

    fun cookiesFor(url: String): String? {
        val host = URI(url).host?.lowercase() ?: return null
        if (!allAnimeHosts.any { host == it || host.endsWith(".$it") }) return null
        return CookieManager.getInstance().getCookie(url)?.takeIf(String::isNotBlank)
    }

    fun flushCookies() {
        CookieManager.getInstance().flush()
    }

    fun isTrustedWebViewUrl(url: String): Boolean {
        val uri = runCatching { URI(url) }.getOrNull() ?: return false
        if (uri.scheme != "https") return false
        val host = uri.host?.lowercase() ?: return false
        return allAnimeHosts.any { host == it || host.endsWith(".$it") } ||
            host in challengeHosts
    }
}
