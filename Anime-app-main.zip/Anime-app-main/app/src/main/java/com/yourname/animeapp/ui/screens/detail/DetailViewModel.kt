package com.yourname.animeapp.ui.screens.detail

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yourname.animeapp.core.data.AnimeRepository
import com.yourname.animeapp.core.data.DownloadRepository
import com.yourname.animeapp.core.data.db.DownloadEntity
import com.yourname.animeapp.core.data.db.DownloadStatus
import com.yourname.animeapp.core.data.model.AnimeDetails
import com.yourname.animeapp.core.data.model.Episode
import com.yourname.animeapp.core.data.model.Quality
import com.yourname.animeapp.core.data.settings.SettingsRepository
import com.yourname.animeapp.sources.allanime.CaptchaRequiredException
import com.yourname.animeapp.ui.util.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DetailState(
    val details: UiState<AnimeDetails> = UiState.Loading,
    val allEpisodes: List<Episode> = emptyList(),
    val selectedTranslation: String = "sub",
    val downloads: List<DownloadEntity> = emptyList(),
    val downloadingAll: Boolean = false,
    val downloadAllProgress: Pair<Int, Int>? = null,
    val message: String? = null,
    val captchaUrl: String? = null,
    val pendingDownload: Episode? = null,
    val pendingDownloadAll: Boolean = false,
    val pendingReload: Boolean = false,
) {
    val filteredEpisodes: List<Episode>
        get() = allEpisodes.filter { it.translationType == selectedTranslation }
            .sortedBy { it.number }

    val hasSub: Boolean get() = allEpisodes.any { it.translationType == "sub" }
    val hasDub: Boolean get() = allEpisodes.any { it.translationType == "dub" }

    fun downloadFor(episodeId: String): DownloadEntity? =
        downloads.find { it.episodeId == episodeId }
}

@HiltViewModel
class DetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val animeRepo: AnimeRepository,
    private val downloadRepo: DownloadRepository,
    private val settings: SettingsRepository,
) : ViewModel() {

    private val animeId: String = savedStateHandle["animeId"] ?: ""

    private val _state = MutableStateFlow(DetailState())
    val state: StateFlow<DetailState> = _state.asStateFlow()

    init {
        load()
        viewModelScope.launch {
            downloadRepo.observeForAnime(animeId).collect { dls ->
                _state.value = _state.value.copy(downloads = dls)
            }
        }
    }

    fun load() {
        viewModelScope.launch {
            _state.value = _state.value.copy(
                details = UiState.Loading,
                captchaUrl = null,
                pendingReload = false,
            )
            try {
                val d = animeRepo.details(animeId)
                val eps = animeRepo.episodes(animeId)
                val savedPreference = settings.defaultAudio.first()
                val preferred = when {
                    eps.any { it.translationType == savedPreference } -> savedPreference
                    eps.any { it.translationType == "sub" } -> "sub"
                    else -> "dub"
                }
                _state.value = _state.value.copy(
                    details = UiState.Success(d),
                    allEpisodes = eps,
                    selectedTranslation = preferred,
                )
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (captcha: CaptchaRequiredException) {
                _state.value = _state.value.copy(
                    details = UiState.Error(captcha.message ?: "CAPTCHA required"),
                    captchaUrl = captcha.challengeUrl,
                    pendingReload = true,
                )
            } catch (error: Exception) {
                _state.value = _state.value.copy(
                    details = UiState.Error(error.message ?: "Failed to load")
                )
            }
        }
    }

    fun selectTranslation(t: String) {
        _state.value = _state.value.copy(selectedTranslation = t)
    }

    fun downloadEpisode(ep: Episode) {
        viewModelScope.launch {
            val details = (_state.value.details as? UiState.Success)?.data ?: return@launch
            val quality = currentQuality()
            val result = downloadRepo.enqueue(
                animeId = details.id,
                animeTitle = details.title,
                coverUrl = details.coverUrl,
                episode = ep,
                quality = quality,
            )
            val captcha = result.exceptionOrNull() as? CaptchaRequiredException
            if (captcha != null) {
                _state.value = _state.value.copy(
                    captchaUrl = captcha.challengeUrl,
                    pendingDownload = ep,
                    pendingDownloadAll = false,
                    pendingReload = false,
                    message = null,
                )
                return@launch
            }
            _state.value = _state.value.copy(
                message = result.fold(
                    onSuccess = { "Download queued" },
                    onFailure = { "Failed: ${it.message ?: "unknown"}" }
                ),
                pendingDownload = null,
                pendingDownloadAll = false,
                pendingReload = false,
            )
        }
    }

    fun downloadAll() {
        viewModelScope.launch {
            val details = (_state.value.details as? UiState.Success)?.data ?: return@launch
            val eps = _state.value.filteredEpisodes
            if (eps.isEmpty()) return@launch

            _state.value = _state.value.copy(
                downloadingAll = true,
                downloadAllProgress = 0 to eps.size,
                captchaUrl = null,
                pendingDownload = null,
                pendingDownloadAll = false,
                pendingReload = false,
            )
            val quality = currentQuality()
            var failed = 0
            var captcha: CaptchaRequiredException? = null
            try {
                for ((i, ep) in eps.withIndex()) {
                    val r = downloadRepo.enqueue(
                        animeId = details.id,
                        animeTitle = details.title,
                        coverUrl = details.coverUrl,
                        episode = ep,
                        quality = quality,
                    )
                    val error = r.exceptionOrNull()
                    if (error is CaptchaRequiredException) {
                        captcha = error
                        break
                    }
                    if (r.isFailure) failed++
                    _state.value = _state.value.copy(downloadAllProgress = (i + 1) to eps.size)
                    delay(200)
                }
            } finally {
                if (isActive) {
                    val captchaError = captcha
                    if (captchaError != null) {
                        _state.value = _state.value.copy(
                            downloadingAll = false,
                            downloadAllProgress = null,
                            message = null,
                            captchaUrl = captchaError.challengeUrl,
                            pendingDownload = null,
                            pendingDownloadAll = true,
                            pendingReload = false,
                        )
                    } else {
                        val msg = if (failed == 0) "Queued ${eps.size} episodes"
                        else "Queued ${eps.size - failed} of ${eps.size} (failed: $failed)"
                        _state.value = _state.value.copy(
                            downloadingAll = false,
                            downloadAllProgress = null,
                            message = msg,
                            captchaUrl = null,
                            pendingDownload = null,
                            pendingDownloadAll = false,
                            pendingReload = false,
                        )
                    }
                }
            }
        }
    }

    fun dismissCaptcha() {
        _state.value = _state.value.copy(
            captchaUrl = null,
            pendingDownload = null,
            pendingDownloadAll = false,
            pendingReload = false,
        )
    }

    fun retryAfterCaptcha() {
        val pendingAll = _state.value.pendingDownloadAll
        val pending = _state.value.pendingDownload
        val reload = _state.value.pendingReload
        _state.value = _state.value.copy(
            captchaUrl = null,
            pendingDownload = null,
            pendingDownloadAll = false,
            pendingReload = false,
        )
        when {
            pendingAll -> downloadAll()
            pending != null -> downloadEpisode(pending)
            reload -> load()
        }
    }

    fun consumeMessage() {
        _state.value = _state.value.copy(message = null)
    }

    private suspend fun currentQuality(): Quality =
        when (settings.defaultQuality.first()) {
            "1080" -> Quality.Q1080
            "720" -> Quality.Q720
            "480" -> Quality.Q480
            else -> Quality.AUTO
        }
}
