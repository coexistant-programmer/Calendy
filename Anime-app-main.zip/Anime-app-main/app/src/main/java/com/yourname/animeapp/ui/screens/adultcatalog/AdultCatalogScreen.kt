package com.yourname.animeapp.ui.screens.adultcatalog

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.yourname.animeapp.sources.adultcatalog.AdultAnimeMetadata
import com.yourname.animeapp.ui.util.UiState

@Composable
fun AdultCatalogScreen(
    onLeave: () -> Unit,
    viewModel: AdultCatalogViewModel = hiltViewModel()
) {
    val ageConfirmed by viewModel.ageConfirmed.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()
    val results by viewModel.results.collectAsStateWithLifecycle()
    var selectedAnime by remember { mutableStateOf<AdultAnimeMetadata?>(null) }

    if (!ageConfirmed) {
        AgeConfirmation(
            onConfirm = viewModel::confirmAge,
            onLeave = onLeave
        )
        return
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 140.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Adult catalog",
                    style = MaterialTheme.typography.displaySmall,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = viewModel::lockCatalog) {
                    Icon(Icons.Rounded.Lock, contentDescription = "Lock adult catalog")
                }
            }
        }
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
            OutlinedTextField(
                value = query,
                onValueChange = viewModel::updateQuery,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search adult anime metadata") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    imeAction = ImeAction.Search
                )
            )
        }
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
            Text(
                "Metadata only; this catalog does not provide episodes or video streams.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        when (val state = results) {
            UiState.Loading -> item(
                span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }
            ) {
                Box(
                    Modifier.fillMaxWidth().height(180.dp),
                    contentAlignment = Alignment.Center
                ) { CircularProgressIndicator() }
            }
            is UiState.Error -> item(
                span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }
            ) {
                Text(state.message, color = MaterialTheme.colorScheme.error)
            }
            is UiState.Success -> items(state.data, key = { it.id }) { anime ->
                AdultAnimeCard(anime = anime, onClick = { selectedAnime = anime })
            }
        }
    }

    selectedAnime?.let { anime ->
        AlertDialog(
            onDismissRequest = { selectedAnime = null },
            title = { Text(anime.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    anime.rating?.let { Text("Rating: $it") }
                    anime.score?.let { Text("Score: $it") }
                    Text(anime.synopsis ?: "No synopsis available.")
                    Text(
                        "Catalog information only. No playback is available.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedAnime = null }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun AgeConfirmation(
    onConfirm: () -> Unit,
    onLeave: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Adult catalog", style = MaterialTheme.typography.headlineMedium)
        Text(
            "This catalog contains metadata for hentai anime, including mature titles. " +
                "It does not provide playback. Continue only if you are of legal adult age " +
                "where you live.",
            modifier = Modifier.padding(vertical = 16.dp),
            style = MaterialTheme.typography.bodyLarge
        )
        Button(onClick = onConfirm, modifier = Modifier.fillMaxWidth()) {
            Text("I confirm I am of legal adult age")
        }
        TextButton(onClick = onLeave) { Text("Not now") }
    }
}

@Composable
private fun AdultAnimeCard(
    anime: AdultAnimeMetadata,
    onClick: () -> Unit
) {
    Column(modifier = Modifier.clickable(onClick = onClick)) {
        AsyncImage(
            model = anime.imageUrl,
            contentDescription = anime.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(MaterialTheme.shapes.large)
        )
        Text(
            anime.title,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp, start = 4.dp, end = 4.dp)
        )
    }
}
