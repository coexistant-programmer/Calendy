package com.yourname.animeapp.ui.navigation

import android.net.Uri

sealed class Destination(val route: String) {
    data object Home : Destination("home")
    data object Search : Destination("search")
    data object Downloads : Destination("downloads")
    data object History : Destination("history")
    data object Settings : Destination("settings")
    data object CookieSessionBrowser : Destination("cookie-session-browser")
    data object AdultCatalog : Destination("adult-catalog")

    data object Detail : Destination("detail/{sourceId}/{animeId}") {
        fun create(sourceId: String, animeId: String): String =
            "detail/${Uri.encode(sourceId)}/${Uri.encode(animeId)}"
    }

    data object Player : Destination("player/{animeId}/{episodeId}") {
        fun create(animeId: String, episodeId: String): String =
            "player/${Uri.encode(animeId)}/${Uri.encode(episodeId)}"
    }
}
