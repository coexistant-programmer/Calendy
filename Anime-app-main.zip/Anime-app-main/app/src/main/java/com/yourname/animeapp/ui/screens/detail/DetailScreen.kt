package com.yourname.animeapp.ui.screens.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.yourname.animeapp.core.data.db.DownloadStatus
import com.yourname.animeapp.core.data.model.AnimeDetails
import com.yourname.animeapp.core.data.model.Episode
import com.yourname.animeapp.sources.allanime.AllAnimeWebSession
import com.yourname.animeapp.ui.components.AllAnimeCaptchaDialog
import com.yourname.animeapp.ui.util.UiState
import com.yourname.animeapp.ui.util.formatEpisodeLabel

@Composable
fun DetailScreen(
    onBack: () -> Unit,
    onEpisodeClick: (Episode) -> Unit,
    viewModel: DetailViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.consumeMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        when (val details = state.details) {
            is UiState.Loading -> Box(
                Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }

            is UiState.Error -> Box(
                Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(details.message, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = { viewModel.load() }) { Text("Retry") }
                }
            }

            is UiState.Success -> DetailBody(
                anime = details.data,
                state = state,
                padding = padding,
                onBack = onBack,
                onTranslation = viewModel::selectTranslation,
                onEpisodeClick = onEpisodeClick,
                onDownloadEpisode = viewModel::downloadEpisode,
                onDownloadAll = viewModel::downloadAll
            )
        }
    }

    state.captchaUrl?.let { captchaUrl ->
        AllAnimeCaptchaDialog(
            url = captchaUrl,
            onDismiss = viewModel::dismissCaptcha,
            onRetry = {
                AllAnimeWebSession.flushCookies()
                viewModel.retryAfterCaptcha()
            }
        )
    }
}

@Composable
private fun DetailBody(
    anime: AnimeDetails,
    state: DetailState,
    padding: PaddingValues,
    onBack: () -> Unit,
    onTranslation: (String) -> Unit,
    onEpisodeClick: (Episode) -> Unit,
    onDownloadEpisode: (Episode) -> Unit,
    onDownloadAll: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Hero
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
            ) {
                AsyncImage(
                    model = anime.coverUrl,
                    contentDescription = anime.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.5f),
                                    Color.Transparent,
                                    Color.Black.copy(alpha = 0.75f)
                                )
                            )
                        )
                )
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .padding(12.dp)
                        .align(Alignment.TopStart)
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color.Black.copy(alpha = 0.35f)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(20.dp)
                ) {
                    Text(
                        text = anime.title,
                        style = MaterialTheme.typography.headlineLarge,
                        color = Color.White,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (anime.year != null || anime.status != null) {
                        Text(
                            text = listOfNotNull(anime.year?.toString(), anime.status).joinToString(" · "),
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }
            }
        }

        // Synopsis
        anime.synopsis?.takeIf { it.isNotBlank() }?.let { syn ->
            item {
                Text(
                    text = syn,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                    maxLines = 6,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Audio toggle
        if (state.hasSub || state.hasDub) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (state.hasSub) {
                        FilterChip(
                            selected = state.selectedTranslation == "sub",
                            onClick = { onTranslation("sub") },
                            label = { Text("Sub") }
                        )
                    }
                    if (state.hasDub) {
                        FilterChip(
                            selected = state.selectedTranslation == "dub",
                            onClick = { onTranslation("dub") },
                            label = { Text("Dub") }
                        )
                    }
                }
            }
        }

        // Download all
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp)
            ) {
                Button(
                    onClick = onDownloadAll,
                    enabled = !state.downloadingAll && state.filteredEpisodes.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Download, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (state.downloadingAll) "Downloading…"
                        else "Download All (${state.filteredEpisodes.size})"
                    )
                }
                state.downloadAllProgress?.let { (done, total) ->
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { if (total > 0) done.toFloat() / total else 0f },
                        modifier = Modifier.fillMaxWidth().height(3.dp)
                    )
                    Text(
                        text = "$done / $total",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // Episode header
        item {
            Text(
                text = "Episodes · ${state.filteredEpisodes.size}",
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
            )
        }

        items(state.filteredEpisodes, key = { it.id }) { ep ->
            val download = state.downloadFor(ep.id)
            EpisodeRow(
                episode = ep,
                downloadStatus = download?.status,
                progress = if (download != null && download.totalBytes > 0)
                    download.bytesDownloaded.toFloat() / download.totalBytes
                else null,
                onPlay = { onEpisodeClick(ep) },
                onDownload = { onDownloadEpisode(ep) }
            )
        }
    }
}

@Composable
private fun EpisodeRow(
    episode: Episode,
    downloadStatus: String?,
    progress: Float?,
    onPlay: () -> Unit,
    onDownload: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onPlay)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = formatEpisodeLabel(episode.number, episode.translationType),
                style = MaterialTheme.typography.titleMedium
            )
            if (progress != null && downloadStatus == DownloadStatus.DOWNLOADING) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                        .height(3.dp)
                )
            }
        }
        when (downloadStatus) {
            DownloadStatus.COMPLETED -> Icon(
                Icons.Rounded.Check,
                contentDescription = "Downloaded",
                tint = MaterialTheme.colorScheme.primary
            )
            DownloadStatus.QUEUED, DownloadStatus.DOWNLOADING ->
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            else -> IconButton(onClick = onDownload) {
                Icon(Icons.Rounded.Download, contentDescription = "Download")
            }
        }
        Spacer(Modifier.width(4.dp))
        IconButton(onClick = onPlay) {
            Icon(Icons.Rounded.PlayArrow, contentDescription = "Play")
        }
    }
}
