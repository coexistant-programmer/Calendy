package com.yourname.animeapp.di

import com.yourname.animeapp.core.data.model.AnimeSource
import com.yourname.animeapp.sources.allanime.AllAnimeSource
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class SourceModule {

    @Binds @Singleton
    abstract fun bindAnimeSource(impl: AllAnimeSource): AnimeSource
}
