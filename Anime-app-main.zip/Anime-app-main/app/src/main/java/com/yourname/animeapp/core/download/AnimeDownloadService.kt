package com.yourname.animeapp.core.download

import android.app.Notification
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.scheduler.Scheduler
import com.yourname.animeapp.AnimeApp
import com.yourname.animeapp.R
import com.yourname.animeapp.core.data.DownloadRepository
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
@AndroidEntryPoint
class AnimeDownloadService : DownloadService(
    /* foregroundNotificationId = */ 1001,
    /* foregroundNotificationUpdateInterval = */ 1000L,
    /* channelId = */ AnimeApp.CHANNEL_DOWNLOAD,
    /* channelNameResourceId = */ R.string.download_channel_name,
    /* channelDescriptionResourceId = */ R.string.download_channel_desc
), DownloadManager.Listener {
    @Inject
    lateinit var injectedDownloadManager: DownloadManager

    @Inject
    lateinit var downloadRepository: DownloadRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        injectedDownloadManager.addListener(this)
    }

    override fun getDownloadManager(): DownloadManager = injectedDownloadManager

    override fun getScheduler(): Scheduler? = null

    override fun getForegroundNotification(
        downloads: List<Download>,
        notMetRequirements: Int,
    ): Notification {
        val helper = DownloadNotificationHelper(this, AnimeApp.CHANNEL_DOWNLOAD)
        return helper.buildProgressNotification(
            this,
            android.R.drawable.stat_sys_download,
            null,
            null,
            downloads,
            notMetRequirements
        )
    }

    override fun onDownloadChanged(
        downloadManager: DownloadManager,
        download: Download,
        finalException: Exception?,
    ) {
        serviceScope.launch {
            downloadRepository.handleDownloadChanged(download)
        }
    }

    override fun onDestroy() {
        injectedDownloadManager.removeListener(this)
        serviceScope.cancel()
        super.onDestroy()
    }
}
