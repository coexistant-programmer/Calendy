package com.yourname.animeapp.ui.screens.downloads

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yourname.animeapp.core.data.DownloadRepository
import com.yourname.animeapp.core.data.db.DownloadEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    private val repo: DownloadRepository,
) : ViewModel() {

    val downloads: StateFlow<List<DownloadEntity>> =
        repo.observeAll()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun pause(id: String) = repo.pause(id)
    fun resume(id: String) = repo.resume(id)
    fun cancel(id: String) {
        viewModelScope.launch { repo.cancel(id) }
    }
}
