package com.yourname.animeapp.core.work

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.yourname.animeapp.core.data.db.DownloadDao
import com.yourname.animeapp.core.data.db.WatchHistoryDao
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
@HiltWorker
class CacheJanitorWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val downloadManager: DownloadManager,
    private val downloadDao: DownloadDao,
    private val historyDao: WatchHistoryDao,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val cursor = downloadManager.downloadIndex.getDownloads()
            val staleBefore = System.currentTimeMillis() - 6L * 60L * 60L * 1000L
            val toDelete = mutableListOf<String>()

            while (cursor.moveToNext()) {
                val d = cursor.download
                val stale = when (d.state) {
                    Download.STATE_FAILED -> true
                    Download.STATE_STOPPED -> d.updateTimeMs < staleBefore
                    Download.STATE_REMOVING -> true
                    else -> false
                }
                if (stale) toDelete += d.request.id
            }
            cursor.close()

            toDelete.forEach { id ->
                runCatching { downloadManager.removeDownload(id) }
                runCatching { downloadDao.delete(id) }
            }

            val cutoff = System.currentTimeMillis() - 90L * 24L * 60L * 60L * 1000L
            runCatching { historyDao.deleteOlderThan(cutoff) }

            Result.success()
        } catch (t: Throwable) {
            Result.retry()
        }
    }
}
