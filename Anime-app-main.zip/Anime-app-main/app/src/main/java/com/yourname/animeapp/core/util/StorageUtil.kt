package com.yourname.animeapp.core.util

import java.io.File

object StorageUtil {

    fun dirSize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        return dir.walkBottomUp().filter { it.isFile }.sumOf { it.length() }
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val kb = 1024.0
        val mb = kb * 1024
        val gb = mb * 1024
        return when {
            bytes >= gb -> "%.2f GB".format(bytes / gb)
            bytes >= mb -> "%.1f MB".format(bytes / mb)
            bytes >= kb -> "%.0f KB".format(bytes / kb)
            else -> "$bytes B"
        }
    }

    fun clearContents(dir: File?) {
        if (dir == null || !dir.exists()) return
        dir.listFiles()?.forEach { f ->
            runCatching { if (f.isDirectory) f.deleteRecursively() else f.delete() }
        }
    }
}
