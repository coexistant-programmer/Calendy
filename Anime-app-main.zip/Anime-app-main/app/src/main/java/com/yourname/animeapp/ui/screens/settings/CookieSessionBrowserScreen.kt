package com.yourname.animeapp.ui.screens.settings

import android.net.Uri
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import java.net.URI

@Composable
fun CookieSessionBrowserScreen(
    onBack: () -> Unit,
    viewModel: CookieSessionViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val error by viewModel.error.collectAsState()
    val viewModelMessage by viewModel.message.collectAsState()
    var address by remember { mutableStateOf("") }
    var loadedUrl by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var browserMessage by remember { mutableStateOf<String?>(null) }
    var showConsent by remember { mutableStateOf(false) }
    var consentUrl by remember { mutableStateOf<String?>(null) }
    var canGoBack by remember { mutableStateOf(false) }

    val webView = remember(context) {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )

            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.safeBrowsingEnabled = true

            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            CookieManager.getInstance().setAcceptCookie(true)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    val uri = request.url

                    if (uri.scheme != "https" && uri.scheme != "http") {
                        browserMessage = "Only HTTP/HTTPS pages are allowed."
                        return true
                    }

                    if (uri.host.isNullOrBlank() || uri.userInfo != null) {
                        browserMessage = "This page is not a valid website URL."
                        return true
                    }

                    return false
                }

                override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                    loading = true
                    loadedUrl = null
                    browserMessage = null
                }

                override fun onPageFinished(view: WebView, url: String) {
                    loading = false
                    canGoBack = view.canGoBack()
                    CookieManager.getInstance().flush()

                    if (url.startsWith("http://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)) {
                        loadedUrl = url
                        address = url
                    }
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: android.webkit.WebResourceError
                ) {
                    if (request.isForMainFrame) {
                        loading = false
                        browserMessage = "Page could not be loaded: ${error.description}"
                    }
                }
            }
        }
    }

    DisposableEffect(webView) {
        onDispose {
            webView.stopLoading()
            webView.destroy()
        }
    }

    BackHandler(enabled = canGoBack) {
        webView.goBack()
    }

    if (showConsent) {
        AlertDialog(
            onDismissRequest = { showConsent = false },
            title = { Text("Save cookies for this site?") },
            text = {
                Text(
                    "The app will copy the cookies currently available to this page, which may include sign-in/session tokens and preference or analytics cookies. The encrypted snapshot is stored on-device for managing your own site sessions; it is not replayed into app network requests. Cookie values are encrypted with an Android Keystore key, hidden in Settings, never uploaded, and not used for other sites. The embedded browser keeps its own cookies, which this snapshot does not replace or clear.\n\n" +
                        "Continue only for your own account, when permitted by the site's terms, access policies, and applicable privacy laws. This does not bypass login protections or CAPTCHA."
                )
            },
            confirmButton = {
                Button(onClick = {
                    showConsent = false

                    val currentUrl = webView.url ?: consentUrl ?: loadedUrl ?: address
                    CookieManager.getInstance().flush()

                    val cookies = currentUrl?.let { CookieManager.getInstance().getCookie(it) }
                    if (currentUrl == null || cookies.isNullOrBlank()) {
                        browserMessage = "No cookies were found for this page. Sign in first, then try again."
                    } else {
                        viewModel.save(currentUrl, cookies)
                        browserMessage = "Saving encrypted cookie snapshot..."
                    }
                }) { Text("I consent - save cookies") }
            },
            dismissButton = {
                TextButton(onClick = { showConsent = false }) { Text("Cancel") }
            }
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onBack) { Text("Back") }
            Text("Add a site", style = MaterialTheme.typography.headlineSmall)
        }
        Text(
            "Use the site's official API or login flow where available. Embedded browsers may be blocked; complete any CAPTCHA yourself. Only HTTPS is allowed, and the app does not spoof another browser or bypass access controls.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = address,
                onValueChange = {
                    address = it
                    loadedUrl = null
                },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Website address (HTTPS)") }
            )
            Button(
                onClick = {
                    val normalized = normalizeHttpsAddress(address)
                    if (normalized == null) {
                        browserMessage = "Enter a valid HTTPS website address."
                    } else {
                        address = normalized
                        loadedUrl = null
                        loading = true
                        browserMessage = null
                        webView.loadUrl(normalized)
                    }
                },
                modifier = Modifier.padding(top = 8.dp)
            ) { Text("Go") }
        }

        if (loading) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CircularProgressIndicator(modifier = Modifier.height(20.dp))
                Text("Loading page...")
            }
        }

        browserMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        viewModelMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.primary)
        }
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        loadedUrl?.takeIf { !loading }?.let {
            Button(
                onClick = {
                    viewModel.clearError()
                    consentUrl = webView.url ?: loadedUrl
                    showConsent = true
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Import Session Cookies") }
        }

        AndroidView(
            factory = { webView },
            modifier = Modifier.weight(1f).fillMaxWidth()
        )
    }
}

private fun normalizeHttpsAddress(address: String): String? {
    val candidate = address.trim()
    if (candidate.isEmpty() || candidate.any(Char::isWhitespace)) return null
    val url = when {
        candidate.startsWith("https://", ignoreCase = true) -> candidate
        candidate.contains("://") -> return null
        else -> "https://$candidate"
    }
    val uri = runCatching { URI(url) }.getOrNull() ?: return null
    if (!uri.scheme.equals("https", ignoreCase = true) || uri.host.isNullOrBlank()) return null
    if (uri.rawUserInfo != null) return null
    return Uri.parse(url).toString()
}
