package com.yourname.animeapp.sources.allanime

import android.util.Log
import com.yourname.animeapp.core.data.model.AnimeDetails
import com.yourname.animeapp.core.data.model.AnimeSource
import com.yourname.animeapp.core.data.model.AnimeSummary
import com.yourname.animeapp.core.data.model.Episode
import com.yourname.animeapp.core.data.model.PagedResult
import com.yourname.animeapp.core.data.model.Quality
import com.yourname.animeapp.core.data.model.VideoSource
import com.yourname.animeapp.core.util.HexDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.CacheControl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.security.MessageDigest
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import javax.inject.Inject
import javax.inject.Singleton

class CaptchaRequiredException(
    val challengeUrl: String
) : IOException("AllAnime requires a CAPTCHA. Complete it and retry playback.")

private class AllAnimeBlockedException : IOException(
    "AllAnime is blocking this request (HTTP 403) without a CAPTCHA challenge. " +
        "Try again later or use another authorized source."
)

@Singleton
class AllAnimeSource @Inject constructor(
    private val client: OkHttpClient
) : AnimeSource {

    override val id = "allanime"
    override val displayName = "AllAnime"

    private val api = "https://api.mkissa.net/api"
    private val base = "https://mkissa.to"
    private val bootstrapUrl = "https://api.mkissa.net/client-crypto/v1/bootstrap"
    private val captchaUrl = "https://api.mkissa.net/captcha/turnstile"

    // The bootstrap token is derived from the site build. Keep this in sync with
    // the build served by mkissa.to; a mismatch fails with invalid_boot_token.
    private val buildId = "186"
    private val siteHost = "mkissa.to"
    private val siteGroup = "mkissa"
    private val defaultLane = "k7"
    private val queryHash =
        "6b48b24cc684033f90a13879521dc64c9527d698baf1bd78232120767d691eb1"
    private val bootPrefix = "1fwWJAeMU:"
    private val vmFragments = listOf(
        "1KCP6HH4CIw=",
        "AKst81/pPjI=",
        "5DdlrLuAeF0=",
        "Kgtk2A3ZOVk="
    )

    @Volatile
    private var cachedBootstrap: BootstrapSession? = null

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val mediaJson = "application/json".toMediaType()

    // In Kotlin raw strings ("""..."""), a literal $ is written ${'$'}.
    // Using \$ inside a raw string produces a backslash + dollar, NOT a dollar,
    // which is why the earlier version sent broken GraphQL to the API.

    private val SEARCH_QUERY = """
        query(
            ${'$'}search: SearchInput,
            ${'$'}limit: Int,
            ${'$'}page: Int,
            ${'$'}translationType: VaildTranslationTypeEnumType,
            ${'$'}countryOrigin: VaildCountryOriginEnumType
        ) {
            shows(
                search: ${'$'}search,
                limit: ${'$'}limit,
                page: ${'$'}page,
                translationType: ${'$'}translationType,
                countryOrigin: ${'$'}countryOrigin
            ) {
                edges { _id name englishName thumbnail availableEpisodes }
            }
        }
    """.trimIndent()

    private val DETAILS_QUERY = """
        query(${'$'}showId: String!) {
            show(_id: ${'$'}showId) {
                _id name englishName description thumbnail genres status studios
            }
        }
    """.trimIndent()

    private val EPISODES_QUERY = """
        query(${'$'}showId: String!) {
            show(_id: ${'$'}showId) {
                _id availableEpisodesDetail
            }
        }
    """.trimIndent()

    override suspend fun search(query: String, page: Int): PagedResult<AnimeSummary> =
        withContext(Dispatchers.IO) {
            val variables = buildJsonObject {
                putJsonObject("search") {
                    put("allowAdult", false)
                    put("allowUnknown", false)
                    put("query", query)
                }
                put("limit", 26)
                put("page", page)
                put("translationType", "sub")
                put("countryOrigin", "ALL")
            }
            val body = runQuery(variables, SEARCH_QUERY)
            val edges = json.decodeFromString<GqlShows>(body).data?.shows?.edges
                ?: throw IOException("AllAnime returned no search results data")

            PagedResult(
                items = edges.mapNotNull { e ->
                    val showId = e._id ?: return@mapNotNull null
                    val title = e.englishName ?: e.name ?: return@mapNotNull null
                    AnimeSummary(
                        id = showId,
                        sourceId = this@AllAnimeSource.id,
                        title = title,
                        coverUrl = e.thumbnail,
                        availableSub = e.availableEpisodes?.sub ?: 0,
                        availableDub = e.availableEpisodes?.dub ?: 0
                    )
                },
                hasNextPage = edges.size >= 26
            )
        }

    override suspend fun trending(page: Int): PagedResult<AnimeSummary> = search("", page)

    override suspend fun details(animeId: String): AnimeDetails = withContext(Dispatchers.IO) {
        val variables = buildJsonObject { put("showId", animeId) }
        val body = runQuery(variables, DETAILS_QUERY)
        val s = runCatching { json.decodeFromString<GqlShow>(body).data?.show }
            .onFailure { Log.e("AllAnimeSource", "Parsing failed", it) }
            .getOrNull() ?: error("details parse failed")

        AnimeDetails(
            id = animeId,
            sourceId = id,
            title = s.englishName ?: s.name ?: animeId,
            coverUrl = s.thumbnail,
            synopsis = s.description,
            genres = s.genres.orEmpty(),
            year = s.year,
            status = s.status,
            studios = s.studios.orEmpty()
        )
    }

    override suspend fun episodes(animeId: String): List<Episode> = withContext(Dispatchers.IO) {
        val variables = buildJsonObject { put("showId", animeId) }
        val body = runQuery(variables, EPISODES_QUERY)

        val detail = json.decodeFromString<GqlEpisodeList>(body)
            .data?.show?.availableEpisodesDetail.orEmpty()

        val out = mutableListOf<Episode>()

        detail["sub"].orEmpty().forEach { n ->
            n.toDoubleOrNull()?.let {
                out += Episode(
                    id = "$animeId::sub::$n",
                    animeId = animeId,
                    number = it,
                    translationType = "sub"
                )
            }
        }
        detail["dub"].orEmpty().forEach { n ->
            n.toDoubleOrNull()?.let {
                out += Episode(
                    id = "$animeId::dub::$n",
                    animeId = animeId,
                    number = it,
                    translationType = "dub"
                )
            }
        }
        out.sortedWith(compareBy({ it.number }, { it.translationType }))
    }

    override suspend fun streamSources(
        episodeId: String,
        translationType: String,
        quality: Quality
    ): List<VideoSource> = withContext(Dispatchers.IO) {
        val parts = episodeId.split("::")
        if (parts.size != 3) return@withContext emptyList()
        val (showId, _, number) = parts

        val bootstrap = fetchBootstrap()
        val timestamp = System.currentTimeMillis() / TOKEN_INTERVAL_MS * TOKEN_INTERVAL_MS
        val requestToken = createRequestToken(bootstrap, timestamp)
        val variables = buildJsonObject {
            put("showId", showId)
            put("episodeString", number)
            put("translationType", translationType)
        }
        val extensions = buildJsonObject {
            putJsonObject("persistedQuery") {
                put("version", 1)
                put("sha256Hash", queryHash)
            }
            put("aaReq", requestToken)
            put("k", bootstrap.lane)
            AllAnimeCaptchaStore.peek()?.let { (token, provider) ->
                putJsonObject("captcha") {
                    put("token", token)
                    put("provider", provider)
                }
            }
        }
        val requestUrl = api.toHttpUrl().newBuilder()
            .addQueryParameter("variables", variables.toString())
            .addQueryParameter("extensions", extensions.toString())
            .build()

        val request = Request.Builder()
            .url(requestUrl)
            .cacheControl(CacheControl.FORCE_NETWORK)
            .header("x-build-id", buildId)
            .header("x-aa-boot", bootstrap.bootToken)
            .addWebViewCookies(requestUrl.toString())
            .get()
            .build()

        val body = client.newCall(request).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            throwIfChallengeOrBlocked(response, responseBody)
            if (!response.isSuccessful) {
                error("AllAnime source request failed: HTTP ${response.code}")
            }
            responseBody.ifEmpty { error("AllAnime source request returned an empty response") }
        }

        val responseData = json.decodeFromString<GqlSources>(body)
        responseData.errors?.firstOrNull()?.message?.let {
            if (it.contains("NEED_CAPTCHA", ignoreCase = true) || isCaptchaMessage(it)) {
                AllAnimeCaptchaStore.clear()
                throw CaptchaRequiredException(captchaUrl)
            }
            error("AllAnime source request failed: $it")
        }
        AllAnimeCaptchaStore.clear()

        val data = responseData.data ?: error("AllAnime returned no source data")
        val sources = data.tobeparsed?.let { decryptSources(it, bootstrap) } ?: data
        val urls = sources.episode?.sourceUrls.orEmpty()

        val results = coroutineScope {
            urls.map { entry ->
                async { resolveSource(entry) }
            }.awaitAll()
        }.flatten()

        filterByQuality(results, quality)
    }

    /**
     * The site derives a per-build static key, then signs a bootstrap request with
     * HMAC-SHA256. The server returns [BootstrapResponse.partB]; XOR-ing it with the
     * static key yields the AES-GCM key used by both aaReq and encrypted responses.
     */
    private suspend fun fetchBootstrap(): BootstrapSession = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val current = epochFor(now)
        cachedBootstrap?.let { cached ->
            val stillValid = when {
                cached.switchAt != null -> now < cached.switchAt
                else -> cached.epoch == current
            }
            if (stillValid) return@withContext cached
        }

        val staticKey = deriveStaticKey(buildId)
        val epochs = linkedSetOf(previousEpochFor(now), current)
        var lastError: Exception? = null
        var captchaError: CaptchaRequiredException? = null

        for (epoch in epochs) {
            try {
                val bootToken = createBootToken(staticKey, epoch)
                val url = bootstrapUrl.toHttpUrl().newBuilder()
                    .addQueryParameter("buildId", buildId)
                    .addQueryParameter("k", defaultLane)
                    .build()
                val request = Request.Builder()
                    .url(url)
                    .cacheControl(CacheControl.FORCE_NETWORK)
                    .header("x-build-id", buildId)
                    .header("x-aa-boot", bootToken)
                    .addWebViewCookies(url.toString())
                    .get()
                    .build()

                val body = client.newCall(request).execute().use { response ->
                    val responseBody = response.body?.string().orEmpty()
                    if (response.code == 403 && responseBody.contains("invalid_boot_token")) {
                        throw IOException(
                            "AllAnime rejected the build token (HTTP 403). " +
                                "The site build likely changed; update AllAnimeSource.buildId."
                        )
                    }
                    throwIfChallengeOrBlocked(response, responseBody)
                    if (!response.isSuccessful) {
                        throw IOException("AllAnime bootstrap failed: HTTP ${response.code}")
                    }
                    responseBody.ifEmpty { error("AllAnime bootstrap returned an empty response") }
                }

                val parsed = json.decodeFromString<BootstrapResponse>(body)
                val session = BootstrapSession(
                    epoch = parsed.epoch,
                    partB = parsed.partB,
                    switchAt = parsed.switchAt,
                    lane = parsed.k ?: defaultLane,
                    bootToken = bootToken,
                    staticKey = staticKey
                )
                cachedBootstrap = session
                return@withContext session
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: CaptchaRequiredException) {
                captchaError = e
                lastError = e
            } catch (e: Exception) {
                lastError = e
            }
        }

        throw captchaError ?: lastError ?: IOException("AllAnime bootstrap failed")
    }

    private fun epochFor(now: Long): Long = now / EPOCH_MS

    private fun previousEpochFor(now: Long): Long {
        val by = epochFor(now)
        return if (now - by * EPOCH_MS < GRACE_MS && by > 0) by - 1 else by
    }

    private fun deriveStaticKey(buildId: String): ByteArray {
        val input = buildId.toByteArray(Charsets.UTF_8)
        val salt = ByteArray(32)
        for (i in 0 until 32) {
            val c = if (input.isEmpty()) 0 else input[i % input.size].toInt() and 0xFF
            salt[i] = (c xor ((i * SALT_MUL + SALT_ADD) and 0xFF)).toByte()
        }

        val key = ByteArray(32)
        vmFragments.forEachIndexed { l, fragment ->
            val part = Base64.getDecoder().decode(fragment)
            val d = l * 8
            for (f in 0 until 8) {
                key[d + f] = (
                    (part[f].toInt() and 0xFF) xor
                        (salt[(d + f) % salt.size].toInt() and 0xFF) xor
                        ((l * FRAG_MUL + f * FRAG_ADD) and 0xFF)
                    ).toByte()
            }
        }
        return key
    }

    private fun createBootToken(staticKey: ByteArray, epoch: Long): String {
        val inner = hmacSha256(staticKey, "$bootPrefix$buildId".toByteArray(Charsets.UTF_8))
        val message = listOf(buildId, siteHost, siteGroup, defaultLane, epoch.toString())
            .joinToString("+")
            .toByteArray(Charsets.UTF_8)
        return hmacSha256(inner, message).toHex()
    }

    private fun deriveSessionKey(session: BootstrapSession): ByteArray {
        val partB = Base64.getDecoder().decode(session.partB)
        require(partB.size >= 32) { "AllAnime returned an invalid bootstrap key" }
        val key = ByteArray(32)
        for (i in 0 until 32) {
            key[i] = (
                (partB[i].toInt() and 0xFF) xor
                    (session.staticKey[i % session.staticKey.size].toInt() and 0xFF)
                ).toByte()
        }
        return key
    }

    private fun createRequestToken(session: BootstrapSession, timestamp: Long): String {
        val payload = buildJsonObject {
            put("v", 1)
            put("ts", timestamp)
            put("epoch", session.epoch)
            put("buildId", buildId)
            put("qh", queryHash)
            put("k", session.lane)
        }.toString().toByteArray(Charsets.UTF_8)

        val ivSeed = "${session.epoch}:$buildId:$queryHash:$timestamp:${session.lane}"
            .toByteArray(Charsets.UTF_8)
        val iv = MessageDigest.getInstance("SHA-256").digest(ivSeed).copyOf(IV_LENGTH)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.ENCRYPT_MODE,
            SecretKeySpec(deriveSessionKey(session), "AES"),
            GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        )
        val encrypted = cipher.doFinal(payload)
        return Base64.getEncoder().encodeToString(byteArrayOf(TOKEN_VERSION) + iv + encrypted)
    }

    private fun decryptSources(encoded: String, session: BootstrapSession): SrcData {
        val payload = Base64.getDecoder().decode(encoded)
        require(payload.size >= TOKEN_HEADER_LENGTH + GCM_TAG_LENGTH_BYTES) {
            "AllAnime returned an invalid encrypted source response"
        }
        require(payload[0] == TOKEN_VERSION) {
            "AllAnime returned an unsupported encrypted source response"
        }
        val iv = payload.copyOfRange(1, TOKEN_HEADER_LENGTH)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(deriveSessionKey(session), "AES"),
            GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        )
        val decoded = cipher.doFinal(
            payload,
            TOKEN_HEADER_LENGTH,
            payload.size - TOKEN_HEADER_LENGTH
        )
        return json.decodeFromString<SrcData>(decoded.toString(Charsets.UTF_8))
    }

    private fun hmacSha256(key: ByteArray, message: ByteArray): ByteArray {
        val mac = javax.crypto.Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(message)
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it.toInt() and 0xFF) }

    private suspend fun resolveSource(entry: SrcEntry): List<VideoSource> {
        val raw = entry.sourceUrl ?: return emptyList()
        val decoded = HexDecoder.decodeSourceUrl(raw) ?: return emptyList()
        val url = when {
            decoded.startsWith("//") -> "https:$decoded"
            decoded.startsWith("/") -> "$base$decoded"
            else -> decoded
        }
        val lowerUrl = url.lowercase()
        val directMp4 = entry.sourceName.equals("Yt-mp4", ignoreCase = true) ||
            "tools.fast4speed.rsvp" in lowerUrl
        val directHls = lowerUrl.substringBefore('?').endsWith(".m3u8")
        val directFile = lowerUrl.substringBefore('?').endsWith(".mp4")

        if (directMp4 || directHls || directFile) {
            return listOf(
                VideoSource(
                    url = url,
                    quality = guessQualityFromUrl(url),
                    isHls = directHls,
                    isMp4 = directMp4 || directFile,
                    headers = mapOf("Referer" to "$base/")
                )
            )
        }

        return resolveTarget(url)
    }

    private suspend fun resolveTarget(url: String): List<VideoSource> = try {
        val target = url.replace(Regex("/clock(?=\\?|$)"), "/clock.json")
        val req = Request.Builder()
            .url(target)
            .cacheControl(CacheControl.FORCE_NETWORK)
            .header("Referer", url)
            .addWebViewCookies(target)
            .get()
            .build()

        client.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            throwIfChallengeOrBlocked(resp, body)
            if (!resp.isSuccessful) {
                throw IOException("HTTP ${resp.code} resolving source link")
            }
            val ct = resp.header("Content-Type").orEmpty()

            if (ct.contains("mpegurl", ignoreCase = true) ||
                target.substringBefore('?').endsWith(".m3u8", ignoreCase = true)
            ) {
                listOf(
                    VideoSource(
                        url = target,
                        quality = guessQualityFromUrl(target),
                        isHls = true,
                        isMp4 = false,
                        headers = mapOf("Referer" to "$base/")
                    )
                )
            } else {
                val parsed = runCatching { json.decodeFromString<LinksRoot>(body) }.getOrNull()
                val links = parsed?.links.orEmpty().mapNotNull { link ->
                    val linkUrl = link.link ?: return@mapNotNull null
                    val absoluteUrl = when {
                        linkUrl.startsWith("//") -> "https:$linkUrl"
                        linkUrl.startsWith("/") -> "$base$linkUrl"
                        else -> linkUrl
                    }

                    VideoSource(
                        url = absoluteUrl,
                        quality = link.resolutionStr?.toIntOrNull() ?: guessQualityFromUrl(absoluteUrl),
                        isHls = link.hls == true ||
                            absoluteUrl.substringBefore('?').endsWith(".m3u8", ignoreCase = true),
                        isMp4 = link.mp4 == true ||
                            absoluteUrl.substringBefore('?').endsWith(".mp4", ignoreCase = true),
                        headers = link.headers.orEmpty().filterValues { it.isNotBlank() }
                    )
                }
                if (links.isNotEmpty()) {
                    links
                } else {
                    val extracted = extractVideoUrl(body) ?: return@use emptyList()
                    val extractedHeaders = buildMap {
                        put("Referer", url)
                        if (url.contains("ok.ru", ignoreCase = true)) {
                            put("Origin", "https://ok.ru")
                        }
                    }
                    listOf(
                        VideoSource(
                            url = extracted,
                            quality = guessQualityFromUrl(extracted),
                            isHls = extracted.substringBefore('?')
                                .endsWith(".m3u8", ignoreCase = true),
                            isMp4 = extracted.substringBefore('?')
                                .endsWith(".mp4", ignoreCase = true),
                            headers = extractedHeaders
                        )
                    )
                }
            }
        }
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: CaptchaRequiredException) {
        throw e
    } catch (e: AllAnimeBlockedException) {
        throw e
    } catch (e: Exception) {
        Log.w("AllAnimeSource", "Could not resolve a source link", e)
        emptyList()
    }

    private fun extractVideoUrl(body: String): String? {
        val unescaped = body
            .replace("&quot;", "\"")
            .replace("&amp;", "&")
            .replace("\\u0026", "&")
            .replace("\\/", "/")

        val patterns = listOf(
            Regex("\"hlsManifestUrl\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"file\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"src\"\\s*:\\s*\"([^\"]+\\.(?:m3u8|mp4)[^\"]*)\""),
            Regex("https?://[^\"'\\\\\\s]+\\.(?:m3u8|mp4)[^\"'\\\\\\s]*")
        )
        for (pattern in patterns) {
            val match = pattern.find(unescaped) ?: continue
            val value = match.groupValues.getOrNull(1)?.takeIf { it.isNotBlank() }
                ?: match.value
            if (value.isNotBlank()) {
                return value.replace("\\u0026", "&").replace("\\/", "/")
            }
        }
        return null
    }

    private fun filterByQuality(list: List<VideoSource>, q: Quality): List<VideoSource> {
        if (list.isEmpty()) return list
        val sorted = list.sortedByDescending { it.quality }
        return when (q) {
            Quality.AUTO -> sorted
            Quality.Q1080 -> sorted.filter { it.quality == 1080 }.ifEmpty { sorted }
            Quality.Q720 -> sorted.filter { it.quality in 720..1080 }.ifEmpty { sorted }
            Quality.Q480 -> sorted.filter { it.quality in 480..720 }.ifEmpty { sorted }
            Quality.Q360 -> sorted.filter { it.quality in 360..480 }.ifEmpty { sorted }
        }
    }

    private fun guessQualityFromUrl(url: String): Int {
        val s = url.lowercase()
        return when {
            "1080" in s -> 1080
            "720" in s -> 720
            "480" in s -> 480
            "360" in s -> 360
            else -> 0
        }
    }

    private fun runQuery(variables: JsonObject, query: String): String {
        val captcha = AllAnimeCaptchaStore.peek()
        val payload = buildJsonObject {
            put("variables", variables)
            put("query", query)
            captcha?.let { (token, provider) ->
                putJsonObject("extensions") {
                    putJsonObject("captcha") {
                        put("token", token)
                        put("provider", provider)
                    }
                }
            }
        }
        val req = Request.Builder()
            .url(api)
            .cacheControl(CacheControl.FORCE_NETWORK)
            .header("x-build-id", buildId)
            .addWebViewCookies(api)
            .post(payload.toString().toRequestBody(mediaJson))
            .build()

        return client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            throwIfChallengeOrBlocked(r, body)
            if (!r.isSuccessful) {
                throw IOException("AllAnime request failed: HTTP ${r.code}")
            }
            if (body.isBlank()) throw IOException("AllAnime returned an empty response")
            val error = json.decodeFromString<GqlErrors>(body).errors?.firstOrNull()?.message
            if (error != null) {
                if (error.contains("NEED_CAPTCHA", ignoreCase = true) || isCaptchaMessage(error)) {
                    AllAnimeCaptchaStore.clear()
                    throw CaptchaRequiredException(captchaUrl)
                }
                throw IOException("AllAnime request failed: $error")
            }
            if (captcha != null) AllAnimeCaptchaStore.clear()
            body
        }
    }

    private fun Request.Builder.addWebViewCookies(url: String): Request.Builder {
        AllAnimeWebSession.cookiesFor(url)?.let { header("Cookie", it) }
        return this
    }

    private fun throwIfChallengeOrBlocked(response: Response, body: String) {
        val host = response.request.url.host
        if (!isAllAnimeHost(host)) return

        val contentType = response.header("Content-Type").orEmpty()
        val challengeHeader = response.header("cf-mitigated")
            .equals("challenge", ignoreCase = true)
        val challengeText = isCaptchaMessage(body)
        val challengePage = contentType.contains("text/html", ignoreCase = true) && challengeText

        if (challengeHeader || (challengeText && (!response.isSuccessful || challengePage))) {
            throw CaptchaRequiredException(captchaUrl)
        }
        if (response.code == 403) throw AllAnimeBlockedException()
    }

    private fun isCaptchaMessage(message: String): Boolean {
        val normalized = message.lowercase()
        return listOf(
            "captcha",
            "turnstile",
            "challenge-platform",
            "cf-chl-",
            "verify you are human",
            "checking your browser",
            "just a moment",
            "attention required"
        ).any(normalized::contains)
    }

    private fun isAllAnimeHost(host: String): Boolean =
        host == "mkissa.to" || host.endsWith(".mkissa.to") ||
            host == "mkissa.net" || host.endsWith(".mkissa.net")

    @Serializable
    private data class GqlErrors(val errors: List<GqlError>? = null)

    @Serializable
    private data class GqlShows(val data: ShowsData? = null)

    @Serializable
    private data class ShowsData(val shows: ShowsPage? = null)

    @Serializable
    private data class ShowsPage(val edges: List<Edge> = emptyList())

    @Serializable
    private data class Edge(
        @SerialName("_id") val _id: String? = null,
        val name: String? = null,
        val englishName: String? = null,
        val thumbnail: String? = null,
        val availableEpisodes: EpCounts? = null
    )

    @Serializable
    private data class EpCounts(
        val sub: Int = 0, val dub: Int = 0, val raw: Int = 0
    )

    @Serializable
    private data class GqlShow(val data: ShowData? = null)

    @Serializable
    private data class ShowData(val show: Show? = null)

    @Serializable
    private data class Show(
        @SerialName("_id") val _id: String? = null,
        val name: String? = null,
        val englishName: String? = null,
        val description: String? = null,
        val thumbnail: String? = null,
        val genres: List<String>? = null,
        val status: String? = null,
        val year: Int? = null,
        val studios: List<String>? = null
    )

    @Serializable
    private data class GqlEpisodeList(val data: EpisodesData? = null)

    @Serializable
    private data class EpisodesData(val show: ShowEps? = null)

    @Serializable
    private data class ShowEps(
        @SerialName("_id") val _id: String? = null,
        val availableEpisodesDetail: Map<String, List<String>>? = null
    )

    @Serializable
    private data class GqlSources(
        val data: SrcData? = null,
        val errors: List<GqlError>? = null
    )

    @Serializable
    private data class SrcData(
        val episode: SrcEp? = null,
        val tobeparsed: String? = null
    )

    @Serializable
    private data class GqlError(val message: String? = null)

    @Serializable
    private data class BootstrapResponse(
        val epoch: Long,
        val partB: String,
        val switchAt: Long? = null,
        val k: String? = null
    )

    private data class BootstrapSession(
        val epoch: Long,
        val partB: String,
        val switchAt: Long?,
        val lane: String,
        val bootToken: String,
        val staticKey: ByteArray
    )

    @Serializable
    private data class SrcEp(
        val episodeString: String? = null,
        val sourceUrls: List<SrcEntry>? = null
    )

    @Serializable
    private data class SrcEntry(
        val sourceName: String? = null,
        val sourceUrl: String? = null
    )

    @Serializable
    private data class LinksRoot(val links: List<LinkEntry>? = null)

    @Serializable
    private data class LinkEntry(
        val link: String? = null,
        val hls: Boolean? = null,
        val mp4: Boolean? = null,
        val resolutionStr: String? = null,
        val headers: Map<String, String>? = null
    )

    private companion object {
        const val TOKEN_INTERVAL_MS = 300_000L
        const val TOKEN_VERSION: Byte = 1
        const val IV_LENGTH = 12
        const val TOKEN_HEADER_LENGTH = 13
        const val GCM_TAG_LENGTH_BITS = 128
        const val GCM_TAG_LENGTH_BYTES = GCM_TAG_LENGTH_BITS / 8
        const val EPOCH_MS = 604_800_000L
        const val GRACE_MS = 86_400_000L
        const val SALT_MUL = 234
        const val SALT_ADD = 35
        const val FRAG_MUL = 187
        const val FRAG_ADD = 64
    }
}
