package com.yourname.animeapp.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yourname.animeapp.core.data.settings.CookieSession
import com.yourname.animeapp.core.data.settings.CookieSessionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@HiltViewModel
class CookieSessionViewModel @Inject constructor(
    private val repository: CookieSessionRepository
) : ViewModel() {
    val sessions: StateFlow<List<CookieSession>> = repository.sessions

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    init {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { repository.load() }
            } catch (exception: CancellationException) {
                throw exception
            } catch (exception: Exception) {
                _error.value = exception.message ?: "Could not load saved cookie sessions."
            }
        }
    }

    fun save(capturedUrl: String, cookieHeader: String) {
        viewModelScope.launch {
            _message.value = null
            try {
                withContext(Dispatchers.IO) { repository.save(capturedUrl, cookieHeader) }
                _error.value = null
                _message.value = "Encrypted cookie snapshot saved on this device."
            } catch (exception: CancellationException) {
                throw exception
            } catch (exception: Exception) {
                _error.value = exception.message ?: "Could not save this cookie session."
            }
        }
    }

    fun delete(site: String) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { repository.delete(site) }
                _error.value = null
            } catch (exception: CancellationException) {
                throw exception
            } catch (exception: Exception) {
                _error.value = exception.message ?: "Could not delete this cookie session."
            }
        }
    }

    fun clearError() {
        _error.value = null
        _message.value = null
    }
}
