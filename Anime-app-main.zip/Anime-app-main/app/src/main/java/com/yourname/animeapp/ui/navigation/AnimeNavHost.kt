package com.yourname.animeapp.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.yourname.animeapp.ui.player.PlayerScreen
import com.yourname.animeapp.ui.screens.detail.DetailScreen
import com.yourname.animeapp.ui.screens.settings.CookieSessionBrowserScreen
import com.yourname.animeapp.ui.screens.downloads.DownloadsScreen
import com.yourname.animeapp.ui.screens.adultcatalog.AdultCatalogScreen
import com.yourname.animeapp.ui.screens.history.HistoryScreen
import com.yourname.animeapp.ui.screens.home.HomeScreen
import com.yourname.animeapp.ui.screens.search.SearchScreen
import com.yourname.animeapp.ui.screens.settings.SettingsScreen

@Composable
fun AnimeNavHost(nav: NavHostController) {
    NavHost(navController = nav, startDestination = Destination.Home.route) {

        composable(Destination.Home.route) {
            HomeScreen(
                onAnimeClick = { sourceId, animeId ->
                    nav.navigate(Destination.Detail.create(sourceId, animeId))
                },
                onContinueClick = { entry ->
                    nav.navigate(Destination.Player.create(entry.animeId, entry.episodeId))
                }
            )
        }

        composable(Destination.Search.route) {
            SearchScreen(
                onAnimeClick = { sourceId, animeId ->
                    nav.navigate(Destination.Detail.create(sourceId, animeId))
                }
            )
        }

        composable(Destination.Downloads.route) { DownloadsScreen() }

        composable(Destination.History.route) {
            HistoryScreen(
                onEntryClick = { entry ->
                    nav.navigate(Destination.Player.create(entry.animeId, entry.episodeId))
                }
            )
        }

        composable(Destination.Settings.route) {
            SettingsScreen(onAddCookieSession = { nav.navigate(Destination.CookieSessionBrowser.route) })
        }
        composable(Destination.CookieSessionBrowser.route) {
            CookieSessionBrowserScreen(onBack = { nav.popBackStack() })
        }
        composable(Destination.AdultCatalog.route) {
            AdultCatalogScreen(onLeave = { nav.popBackStack() })
        }

        composable(
            route = Destination.Detail.route,
            arguments = listOf(
                navArgument("sourceId") { type = NavType.StringType },
                navArgument("animeId") { type = NavType.StringType }
            )
        ) {
            DetailScreen(
                onBack = { nav.popBackStack() },
                onEpisodeClick = { ep ->
                    nav.navigate(Destination.Player.create(ep.animeId, ep.id))
                }
            )
        }

        composable(
            route = Destination.Player.route,
            arguments = listOf(
                navArgument("animeId") { type = NavType.StringType },
                navArgument("episodeId") { type = NavType.StringType }
            )
        ) {
            PlayerScreen(onBack = { nav.popBackStack() })
        }
    }
}
