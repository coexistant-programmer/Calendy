package com.yourname.animeapp.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yourname.animeapp.core.data.AnimeRepository
import com.yourname.animeapp.core.data.db.WatchHistoryEntity
import com.yourname.animeapp.core.data.model.AnimeSummary
import com.yourname.animeapp.ui.util.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val animeRepo: AnimeRepository,
) : ViewModel() {

    val history: StateFlow<List<WatchHistoryEntity>> =
        animeRepo.observeHistory(20)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _trending = MutableStateFlow<UiState<List<AnimeSummary>>>(UiState.Loading)
    val trending: StateFlow<UiState<List<AnimeSummary>>> = _trending.asStateFlow()

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            _trending.value = UiState.Loading
            try {
                _trending.value = UiState.Success(animeRepo.trending().items)
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Exception) {
                _trending.value = UiState.Error(error.message ?: "Couldn't load")
            }
        }
    }
}
