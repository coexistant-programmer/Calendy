package com.yourname.animeapp.sources.allanime

/**
 * Holds the single-use token produced by AllAnime's Turnstile page.
 *
 * The token is created by the WebView captcha flow and consumed by the next
 * streamSources request. It is deliberately process-local: tokens expire quickly
 * and are not useful across launches.
 */
object AllAnimeCaptchaStore {
    @Volatile
    private var token: String? = null

    @Volatile
    private var provider: String? = null

    fun save(token: String, provider: String) {
        if (token.isBlank()) return
        this.token = token
        this.provider = provider.ifBlank { "turnstile" }
    }

    fun peek(): Pair<String, String>? {
        val value = token ?: return null
        return value to (provider ?: "turnstile")
    }

    fun clear() {
        token = null
        provider = null
    }
}
