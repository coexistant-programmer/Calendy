package com.yourname.animeapp.ui.player

import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs

fun Modifier.playerGestures(
    enabled: Boolean,
    onTap: () -> Unit,
    onDoubleTap: (forward: Boolean) -> Unit,
    onSeek: (deltaMs: Long) -> Unit,
    onBrightness: (delta: Float) -> Unit,
    onVolume: (delta: Float) -> Unit,
    onZoom: (factor: Float) -> Unit
): Modifier {
    if (!enabled) return this
    return this
        .pointerInput(Unit) {
            detectTapGestures(
                onTap = { onTap() },
                onDoubleTap = { offset ->
                    onDoubleTap(offset.x > size.width / 2f)
                }
            )
        }
        .pointerInput(Unit) {
            var mode = 0 // 0 undecided, 1 vertical, 2 horizontal
            var startX = 0f
            var totalX = 0f

            detectDragGestures(
                onDragStart = { offset ->
                    mode = 0
                    startX = offset.x
                    totalX = 0f
                },
                onDrag = { change, drag ->
                    change.consume()
                    if (mode == 0) {
                        mode = if (abs(drag.y) > abs(drag.x)) 1 else 2
                    }
                    when (mode) {
                        1 -> {
                            val delta = -drag.y / size.height.toFloat().coerceAtLeast(1f)
                            if (startX < size.width / 2f) onBrightness(delta)
                            else onVolume(delta)
                        }
                        2 -> totalX += drag.x
                    }
                },
                onDragEnd = {
                    if (mode == 2 && totalX != 0f) {
                        val w = size.width.toFloat().coerceAtLeast(1f)
                        onSeek((totalX / w * 120_000L).toLong())
                    }
                },
                onDragCancel = { totalX = 0f }
            )
        }
        .pointerInput(Unit) {
            detectTransformGestures { _, _, zoom, _ ->
                if (zoom != 1f) onZoom(zoom)
            }
        }
}
