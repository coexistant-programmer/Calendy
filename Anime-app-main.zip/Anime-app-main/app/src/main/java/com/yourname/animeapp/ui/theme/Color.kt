package com.yourname.animeapp.ui.theme

import androidx.compose.ui.graphics.Color

// Fallback palette — used when dynamic color is unavailable (API < 31)
val PurplePrimary = Color(0xFF6B4EFF)
val PurpleOnPrimary = Color(0xFFFFFFFF)
val PurplePrimaryContainer = Color(0xFFE7DEFF)
val PurpleOnPrimaryContainer = Color(0xFF1F0060)

val LavenderSecondary = Color(0xFFB8A8FF)
val LavenderOnSecondary = Color(0xFF2B1B63)
val LavenderSecondaryContainer = Color(0xFFE6DDFF)
val LavenderOnSecondaryContainer = Color(0xFF3B2A73)

val CoralTertiary = Color(0xFFFF7A8B)
val CoralOnTertiary = Color(0xFF4C0018)

val SurfaceLight = Color(0xFFFBF8FF)
val OnSurfaceLight = Color(0xFF1B1B1F)
val SurfaceVariantLight = Color(0xFFE4E1EC)

val SurfaceDark = Color(0xFF131218)
val OnSurfaceDark = Color(0xFFE5E1E9)
val SurfaceVariantDark = Color(0xFF2A2831)
