package com.yourname.animeapp.di

import android.content.Context
import androidx.room.Room
import com.yourname.animeapp.core.data.db.AppDatabase
import com.yourname.animeapp.core.data.db.DownloadDao
import com.yourname.animeapp.core.data.db.SearchHistoryDao
import com.yourname.animeapp.core.data.db.WatchHistoryDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides @Singleton
    fun provideDb(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "anime.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideHistoryDao(db: AppDatabase): WatchHistoryDao = db.watchHistoryDao()
    @Provides fun provideDownloadDao(db: AppDatabase): DownloadDao = db.downloadDao()
    @Provides fun provideSearchHistoryDao(db: AppDatabase): SearchHistoryDao = db.searchHistoryDao()
}
