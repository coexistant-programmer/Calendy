package com.yourname.animeapp.ui.player

import android.content.Context
import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.yourname.animeapp.core.data.AnimeRepository
import com.yourname.animeapp.core.data.db.DownloadDao
import com.yourname.animeapp.core.data.db.DownloadEntity
import com.yourname.animeapp.core.data.db.DownloadStatus
import com.yourname.animeapp.core.data.db.WatchHistoryDao
import com.yourname.animeapp.core.data.model.AnimeDetails
import com.yourname.animeapp.core.data.model.AnimeSource
import com.yourname.animeapp.core.data.model.Episode
import com.yourname.animeapp.core.data.model.Quality
import com.yourname.animeapp.core.data.settings.SettingsRepository
import com.yourname.animeapp.sources.allanime.CaptchaRequiredException
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import javax.inject.Inject

data class TrackOption(
    val groupIndex: Int,
    val trackIndex: Int,
    val label: String,
    val language: String?
) {
    val id: String get() = "$groupIndex:$trackIndex"
}

data class PlayerUiState(
    val animeTitle: String = "",
    val episodeLabel: String = "",
    val isLoading: Boolean = true,
    val error: String? = null,
    val captchaUrl: String? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val audioTracks: List<TrackOption> = emptyList(),
    val textTracks: List<TrackOption> = emptyList(),
    val selectedAudioId: String? = null,
    val selectedTextId: String? = null,
    val isLocked: Boolean = false,
    val speed: Float = 1f
)

@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
@HiltViewModel
class PlayerViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    @ApplicationContext private val context: Context,
    private val animeRepo: AnimeRepository,
    private val source: AnimeSource,
    private val settings: SettingsRepository,
    private val watchDao: WatchHistoryDao,
    private val downloadDao: DownloadDao,
    private val cache: SimpleCache,
    private val okHttpClient: OkHttpClient
) : ViewModel() {

    private val animeId: String = savedStateHandle["animeId"] ?: ""
    private val episodeId: String = savedStateHandle["episodeId"] ?: ""

    private val trackSelector = DefaultTrackSelector(context)
    val player: ExoPlayer = ExoPlayer.Builder(context)
        .setTrackSelector(trackSelector)
        .build()

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    private var currentDetails: AnimeDetails? = null
    private var currentEpisode: Episode? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) = updateTracks(tracks)
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _state.update { it.copy(isPlaying = isPlaying) }
                if (!isPlaying) saveProgress()
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) saveProgress()
                if (playbackState == Player.STATE_READY) {
                    _state.update {
                        it.copy(durationMs = player.duration.coerceAtLeast(0L))
                    }
                }
            }
        })

        viewModelScope.launch { load() }

        viewModelScope.launch {
            while (isActive) {
                if (player.isPlaying) {
                    _state.update {
                        it.copy(positionMs = player.currentPosition.coerceAtLeast(0L))
                    }
                    saveProgress()
                }
                delay(5_000)
            }
        }
    }

    private suspend fun load() {
        _state.update { it.copy(isLoading = true, error = null, captchaUrl = null) }
        try {
            val downloaded = downloadDao.findByEpisode(episodeId)
            val isOfflineDownload = downloaded?.status == DownloadStatus.COMPLETED &&
                (downloaded.exportedUri != null ||
                    downloaded.localPath?.startsWith(DownloadEntity.OFFLINE_HLS_PREFIX) == true ||
                    downloaded.localPath?.startsWith(DownloadEntity.OFFLINE_FILE_PREFIX) == true)

            val details: AnimeDetails
            val episode: Episode
            if (isOfflineDownload && downloaded != null) {
                val parts = episodeId.split("::")
                val number = parts.getOrNull(2)?.toDoubleOrNull()
                    ?: error("Downloaded episode details are invalid")
                episode = Episode(
                    id = episodeId,
                    animeId = downloaded.animeId,
                    number = number,
                    translationType = parts.getOrNull(1)
                        ?: error("Downloaded episode details are invalid")
                )
                details = AnimeDetails(
                    id = downloaded.animeId,
                    sourceId = "allanime",
                    title = downloaded.animeTitle,
                    coverUrl = downloaded.coverUrl,
                    synopsis = null,
                    genres = emptyList(),
                    year = null,
                    status = null,
                    studios = emptyList()
                )
                if (!playDownloaded(downloaded)) error("Downloaded media is unavailable")
            } else {
                val cachedDetails = currentDetails
                val cachedEpisode = currentEpisode
                if (cachedDetails != null && cachedEpisode != null) {
                    details = cachedDetails
                    episode = cachedEpisode
                } else {
                    details = animeRepo.details(animeId)
                    val episodes = animeRepo.episodes(animeId)
                    episode = episodes.firstOrNull { it.id == episodeId }
                        ?: parseEpisode(episodeId, episodes)
                        ?: error("Episode not found")
                    currentDetails = details
                    currentEpisode = episode
                }
                playRemote(episode)
            }

            currentDetails = details
            currentEpisode = episode
            _state.update {
                it.copy(
                    animeTitle = details.title,
                    episodeLabel = labelFor(episode)
                )
            }

            watchDao.get(episodeId)?.let { h ->
                if (h.lastPositionMs > 3_000 && h.lastPositionMs < h.durationMs - 5_000) {
                    player.seekTo(h.lastPositionMs)
                }
            }

            player.prepare()
            player.playWhenReady = true
            _state.update { it.copy(isLoading = false) }
        } catch (captcha: CaptchaRequiredException) {
            _state.update {
                it.copy(
                    isLoading = false,
                    error = captcha.message,
                    captchaUrl = captcha.challengeUrl
                )
            }
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (t: Exception) {
            _state.update {
                it.copy(isLoading = false, error = t.message ?: "Playback failed")
            }
        }
    }

    fun retryAfterCaptcha() {
        if (_state.value.captchaUrl == null || _state.value.isLoading) return
        viewModelScope.launch { load() }
    }

    fun retryPlayback() {
        if (_state.value.isLoading) return
        viewModelScope.launch { load() }
    }

    private fun playLocal(uri: Uri) {
        val mediaSource = ProgressiveMediaSource.Factory(DefaultDataSource.Factory(context))
            .createMediaSource(MediaItem.fromUri(uri))
        player.setMediaSource(mediaSource)
    }

    private fun playDownloaded(download: DownloadEntity): Boolean {
        download.exportedUri?.let {
            playLocal(Uri.parse(it))
            return true
        }

        val localPath = download.localPath ?: return false
        val isHls = localPath.startsWith(DownloadEntity.OFFLINE_HLS_PREFIX)
        val isCachedFile = localPath.startsWith(DownloadEntity.OFFLINE_FILE_PREFIX)
        if (!isHls && !isCachedFile) return false

        val prefix = if (isHls) {
            DownloadEntity.OFFLINE_HLS_PREFIX
        } else {
            DownloadEntity.OFFLINE_FILE_PREFIX
        }
        val uri = Uri.parse(localPath.removePrefix(prefix))
        val dataSourceFactory = CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(OkHttpDataSource.Factory(okHttpClient))
        if (isCachedFile) {
            dataSourceFactory.setCacheKeyFactory { download.id }
        }

        val mediaSource = if (isHls) {
            HlsMediaSource.Factory(dataSourceFactory)
                .createMediaSource(MediaItem.fromUri(uri))
        } else {
            ProgressiveMediaSource.Factory(dataSourceFactory)
                .createMediaSource(MediaItem.fromUri(uri))
        }
        player.setMediaSource(mediaSource)
        return true
    }

    private suspend fun playRemote(episode: Episode) {
        val quality = when (settings.defaultQuality.first()) {
            "1080" -> Quality.Q1080
            "720" -> Quality.Q720
            "480" -> Quality.Q480
            else -> Quality.AUTO
        }
        val sources = source.streamSources(episodeId, episode.translationType, quality)
        val best = sources.firstOrNull() ?: error("No playable source")

        val dsFactory = OkHttpDataSource.Factory(okHttpClient)
            .setDefaultRequestProperties(best.headers)

        val mediaSource = if (best.isHls || best.url.contains(".m3u8", ignoreCase = true)) {
            HlsMediaSource.Factory(dsFactory).createMediaSource(MediaItem.fromUri(best.url))
        } else {
            ProgressiveMediaSource.Factory(dsFactory).createMediaSource(MediaItem.fromUri(best.url))
        }
        player.setMediaSource(mediaSource)
    }

    private fun updateTracks(tracks: Tracks) {
        val audio = mutableListOf<TrackOption>()
        val text = mutableListOf<TrackOption>()
        var selectedAudio: String? = null
        var selectedText: String? = null

        tracks.groups.forEachIndexed { groupIndex, group ->
            when (group.type) {
                C.TRACK_TYPE_AUDIO -> for (i in 0 until group.length) {
                    val f = group.getTrackFormat(i)
                    val option = TrackOption(
                        groupIndex, i,
                        f.label ?: f.language ?: "Audio ${i + 1}",
                        f.language
                    )
                    audio += option
                    if (group.isTrackSelected(i)) selectedAudio = option.id
                }
                C.TRACK_TYPE_TEXT -> for (i in 0 until group.length) {
                    val f = group.getTrackFormat(i)
                    val option = TrackOption(
                        groupIndex, i,
                        f.label ?: f.language ?: "Subtitle ${i + 1}",
                        f.language
                    )
                    text += option
                    if (group.isTrackSelected(i)) selectedText = option.id
                }
            }
        }

        _state.update {
            it.copy(
                audioTracks = audio,
                textTracks = text,
                selectedAudioId = selectedAudio,
                selectedTextId = selectedText
            )
        }
    }

    fun togglePlayPause() {
        if (player.isPlaying) player.pause() else player.play()
    }

    fun seekTo(ms: Long) {
        val target = ms.coerceIn(0L, player.duration.coerceAtLeast(0L))
        player.seekTo(target)
        _state.update { it.copy(positionMs = target) }
    }

    fun seekBy(deltaMs: Long) = seekTo(player.currentPosition + deltaMs)

    fun selectAudio(option: TrackOption) {
        val group = player.currentTracks.groups.getOrNull(option.groupIndex) ?: return
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex))
            .build()
        _state.update { it.copy(selectedAudioId = option.id) }
    }

    fun selectText(option: TrackOption) {
        if (option.groupIndex == -1) {
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            _state.update { it.copy(selectedTextId = null) }
            return
        }
        val group = player.currentTracks.groups.getOrNull(option.groupIndex) ?: return
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex))
            .build()
        _state.update { it.copy(selectedTextId = option.id) }
    }

    fun setSpeed(speed: Float) {
        player.setPlaybackSpeed(speed)
        _state.update { it.copy(speed = speed) }
    }

    fun toggleLock() {
        _state.update { it.copy(isLocked = !it.isLocked) }
    }

    private fun saveProgress() {
        val details = currentDetails ?: return
        val episode = currentEpisode ?: return
        val pos = player.currentPosition
        val dur = player.duration.takeIf { it != C.TIME_UNSET } ?: 0L
        if (pos <= 0L) return
        viewModelScope.launch {
            animeRepo.recordWatch(details, episode, pos, dur)
        }
    }

    private fun parseEpisode(id: String, episodes: List<Episode>): Episode? {
        val parts = id.split("::")
        if (parts.size != 3) return null
        val num = parts[2].toDoubleOrNull() ?: return null
        return episodes.firstOrNull {
            it.translationType == parts[1] && it.number == num
        }
    }

    private fun labelFor(ep: Episode): String {
        val n = if (ep.number % 1.0 == 0.0) ep.number.toInt().toString() else ep.number.toString()
        return "Episode $n · ${ep.translationType.uppercase()}"
    }

    override fun onCleared() {
        player.release()
        super.onCleared()
    }
}
