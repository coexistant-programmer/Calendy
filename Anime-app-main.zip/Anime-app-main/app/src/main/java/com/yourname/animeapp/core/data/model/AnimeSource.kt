package com.yourname.animeapp.core.data.model

// ---- Public domain models (UI talks to these, never to source-specific JSON) ----

data class AnimeSummary(
    val id: String,
    val sourceId: String,
    val title: String,
    val coverUrl: String?,
    val availableSub: Int = 0,
    val availableDub: Int = 0
)

data class AnimeDetails(
    val id: String,
    val sourceId: String,
    val title: String,
    val coverUrl: String?,
    val synopsis: String?,
    val genres: List<String>,
    val year: Int?,
    val status: String?,
    val studios: List<String>
)

data class Episode(
    val id: String,          // composite: "$showId::$translationType::$number"
    val animeId: String,
    val number: Double,
    val translationType: String, // "sub" | "dub"
) {
    val isDub: Boolean get() = translationType == "dub"
    val displayNumber: String
        get() = if (number % 1.0 == 0.0) number.toInt().toString() else number.toString()
}

data class VideoSource(
    val url: String,
    val quality: Int,           // 1080, 720, 480, 0 = unknown/auto
    val isHls: Boolean,
    val isMp4: Boolean,
    val headers: Map<String, String> = emptyMap()
)

data class PagedResult<T>(
    val items: List<T>,
    val hasNextPage: Boolean
)

enum class Quality { AUTO, Q1080, Q720, Q480, Q360 }

enum class AudioPref { SUB, DUB }

// ---- The interface every source must implement ----

interface AnimeSource {
    val id: String
    val displayName: String

    suspend fun trending(page: Int = 1): PagedResult<AnimeSummary>
    suspend fun search(query: String, page: Int = 1): PagedResult<AnimeSummary>
    suspend fun details(animeId: String): AnimeDetails
    suspend fun episodes(animeId: String): List<Episode>

    /**
     * Resolve playable/downloadable sources for one episode.
     * This is the call that must be made at download-click time, NOT queue time —
     * HLS tokens expire.
     */
    suspend fun streamSources(
        episodeId: String,
        translationType: String,
        quality: Quality = Quality.AUTO
    ): List<VideoSource>
}
