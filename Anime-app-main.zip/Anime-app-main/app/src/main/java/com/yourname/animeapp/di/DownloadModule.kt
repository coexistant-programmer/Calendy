package com.yourname.animeapp.di

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.offline.DownloadManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import java.io.File
import java.util.concurrent.Executors
import javax.inject.Singleton

@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
@Module
@InstallIn(SingletonComponent::class)
object DownloadModule {

    @Provides @Singleton
    fun provideStandaloneDb(@ApplicationContext ctx: Context): StandaloneDatabaseProvider =
        StandaloneDatabaseProvider(ctx)

    @Provides @Singleton
    fun provideSimpleCache(
        @ApplicationContext ctx: Context,
        db: StandaloneDatabaseProvider,
    ): SimpleCache {
        val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "downloads_cache")
        return SimpleCache(dir, NoOpCacheEvictor(), db)
    }

    @Provides @Singleton
    fun provideDownloadDataSourceFactory(client: OkHttpClient): DataSource.Factory =
        OkHttpDataSource.Factory(client)

    @Provides @Singleton
    fun provideDownloadManager(
        @ApplicationContext ctx: Context,
        db: StandaloneDatabaseProvider,
        cache: SimpleCache,
        dataSourceFactory: DataSource.Factory,
    ): DownloadManager = DownloadManager(
        ctx,
        db,
        cache,
        dataSourceFactory,
        Executors.newFixedThreadPool(4)
    )
}
