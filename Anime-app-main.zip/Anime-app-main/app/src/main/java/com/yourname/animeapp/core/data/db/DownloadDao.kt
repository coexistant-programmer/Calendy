package com.yourname.animeapp.core.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: DownloadEntity)

    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE animeId = :animeId ORDER BY episodeNumber ASC")
    fun observeForAnime(animeId: String): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun get(id: String): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE episodeId = :episodeId LIMIT 1")
    suspend fun findByEpisode(episodeId: String): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status IN (:statuses)")
    suspend fun byStatus(statuses: List<String>): List<DownloadEntity>

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM downloads")
    suspend fun clearAll()

    @Query("UPDATE downloads SET status = :status, bytesDownloaded = :bytes, totalBytes = :total, updatedAt = :now WHERE id = :id")
    suspend fun updateProgress(id: String, status: String, bytes: Long, total: Long, now: Long)

    @Query("UPDATE downloads SET status = :status, exportedUri = :uri, localPath = :localPath, updatedAt = :now WHERE id = :id")
    suspend fun markCompleted(
        id: String,
        status: String,
        uri: String?,
        localPath: String?,
        now: Long
    )

    @Query("UPDATE downloads SET status = :status, error = :error, updatedAt = :now WHERE id = :id")
    suspend fun markFailed(id: String, status: String, error: String?, now: Long)
}
