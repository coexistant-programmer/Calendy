package com.yourname.animeapp.core.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "downloads",
    indices = [
        Index("animeId"),
        Index("status"),
        Index(value = ["episodeId"], unique = true)
    ]
)
data class DownloadEntity(
    @PrimaryKey val id: String,                 // Media3 DownloadRequest id
    val animeId: String,
    val animeTitle: String,
    val coverUrl: String?,
    val episodeId: String,                      // composite source episode id
    val episodeNumber: Double,
    val translationType: String,
    val quality: String,
    val status: String,                         // QUEUED|DOWNLOADING|PAUSED|COMPLETED|FAILED
    val bytesDownloaded: Long,
    val totalBytes: Long,
    val localPath: String?,                     // app-private path in SimpleCache (media3)
    val exportedUri: String?,                   // SAF Uri after export to user folder
    val error: String?,
    val createdAt: Long,
    val updatedAt: Long
) {
    companion object {
        const val OFFLINE_HLS_PREFIX = "offline-hls:"
        const val OFFLINE_FILE_PREFIX = "offline-file:"
    }
}

object DownloadStatus {
    const val QUEUED = "QUEUED"
    const val DOWNLOADING = "DOWNLOADING"
    const val PAUSED = "PAUSED"
    const val COMPLETED = "COMPLETED"
    const val FAILED = "FAILED"
}
