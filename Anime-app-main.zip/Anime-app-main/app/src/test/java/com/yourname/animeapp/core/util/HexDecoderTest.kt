package com.yourname.animeapp.core.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HexDecoderTest {

    @Test
    fun decodesXorObfuscatedUrl() {
        assertEquals("/clock.json", HexDecoder.decodeSourceUrl("--175b54575b5316524b5756"))
    }

    @Test
    fun decodesHexPath() {
        assertEquals("/foo", HexDecoder.decodeSourceUrl("ap/2f666f6f"))
    }

    @Test
    fun preservesPlainUrl() {
        assertEquals("https://example.test/video.m3u8", HexDecoder.decodeSourceUrl(
            "https://example.test/video.m3u8"
        ))
    }

    @Test
    fun rejectsMalformedEncodedUrl() {
        assertNull(HexDecoder.decodeSourceUrl("--123"))
        assertNull(HexDecoder.decodeSourceUrl("--xx"))
    }
}
